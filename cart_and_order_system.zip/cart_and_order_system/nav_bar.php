<header>
    <h3>Customer Cart and Order System</h3>
</header>
<nav>
    <ul>
        <li><a href="login_form.php">Login</a></li>
        <li><a href="cart.php">Cart</a></li>
        <li><a href="register_form.php">Register</a></li>
    </ul>
</nav>