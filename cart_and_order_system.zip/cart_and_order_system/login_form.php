<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
        <?php include_once('nav_bar.php') ?>
        <main>
            <form action="process/login_process.php" method="post">
                <label for="Email">Email</label>
                <input type="email" name="Email">
                <label for="Password">Password</label>
                <input type="password" name="Password">
                <button type="submit">Login</button>
            </form>
        </main>
</body>
</html>