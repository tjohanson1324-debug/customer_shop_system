<?php require_once 'include/database.php';
$OrderId = $_GET['order_id'];

$sql = 'SELECT o.*, oi.Price, p.ProductName, oi.Quantity, p.DiscountPercent, o.Total FROM CustomerOrder o
JOIN OrderItem oi ON o.ID = oi.CustomerOrderID
JOIN Product p ON oi.ProductID = p.ID
Where o.ID = :ID';
$stmt = $db->prepare($sql);
$stmt->execute([':ID' => $OrderId]);
$OrderItems = $stmt->fetchAll(PDO::FETCH_ASSOC);

?>
<!doctype html>
<html>

<head>
    <meta charset="utf-8">
    <title>Xdebug Order Lab</title>
    <link rel="stylesheet" href="style.css">
</head>

<body>
        <?php include_once('nav_bar.php') ?>
    <main>
        <h1>Order</h1>
        <h1>Items</h1>
        <table>
            <tr>
                <th>Product Name</th>
                <th>Quantity</th>
                <th>Unit Price*</th>
                <th>Price*</th>
            </tr><?php foreach ($OrderItems as $o): ?>
                <tr>
                    <td><?= htmlspecialchars($o['ProductName']) ?></td>
                    <td><?= $o['Quantity'] ?></td>
                    <td>$<?= $o['Price'] ?> </td>
                    <td>$<?= number_format($o['Price'] * $o['Quantity'], 2) ?></td>
                </tr><?php endforeach; ?>
        </table>
        <table>
            <tr>
                <th>
                    Subtotal*
                </th>
                <th>
                    Shipping
                </th>
                <th>
                    Tax
                </th>
                <th>
                    Total*
                </th>
            </tr>
                <td>$<?= number_format($o['Subtotal'],2) ?></td>
                <td>$<?= number_format($o['Shipping'],2) ?></td>
                <td>$<?= number_format($o['Tax'],2) ?></td>
                <td>$<?= number_format($o['Total'],2) ?></td>
            </tr>
        </table>
        <p>*These are the prices at purchase</p>
    </main>
</body>

</html>