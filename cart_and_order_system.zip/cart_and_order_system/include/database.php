<?php
$dsn = 'mysql:host=db;dbname=demo;charset=utf8mb4';
$username = 'user';
$password = 'password';
$options = [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION];
try { $db = new PDO($dsn, $username, $password, $options); }
catch (PDOException $e) { exit('Database connection failed: ' . $e->getMessage()); }
