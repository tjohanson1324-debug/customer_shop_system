<?php
function calculateOrderTotal(float $price, int $quantity, float $discountPercent): float
{
    $subtotal = $price * $quantity;
    $discount = $subtotal * ($discountPercent /100);
    return $subtotal - $discount;
}

function getShippingCost(float $subtotal): float
{
    // Business rule: orders of $50 or more receive FREE shipping.
    if ($subtotal < 50) {
        return 8.95;
    }
    return 0;
}

function calculateTax(float $subtotal, float $taxRate): float
{
    return $subtotal * ($taxRate / 100);
}
