# Xdebug Debugging Assignment — Customer Order System

## Purpose

The Customer Order System runs, but it contains several logic errors.

Your job is to use **Xdebug and the VS Code debugger** to locate and correct the problems. Do not rewrite the application. Debug the existing code and make the smallest reasonable corrections.

## Setup

1. Copy the PHP files into a folder inside the `php` directory used by our class Docker environment.
2. Run `xdebug_assignment.sql` in MySQL/phpMyAdmin.
3. Open the project folder in VS Code.
4. Start **Listen for Xdebug**.
5. Open the application in your browser.

## Business Rules

The application should follow these rules:

- The selected customer should be saved with the order.
- The selected product should be used to determine the product price.
- Quantity should be the quantity entered by the user.
- A discount of `10` means **10%**, not 10 times the subtotal.
- Orders with a subtotal of **$50.00 or more receive free shipping**.
- Orders under $50.00 have a shipping charge of **$8.95**.
- Tax is **5.5%** of the discounted merchandise total.
- The final total is:

  `Discounted Merchandise Total + Shipping + Tax`

## Debugger Requirements

Use Xdebug while working on the assignment. You should be able to demonstrate the following:

- Set a breakpoint.
- Start a debugging session.
- Use **Continue**.
- Use **Step Over**.
- Use **Step Into**.
- Inspect values in the **Variables** window.
- Add at least one variable to **Watch**.
- Examine the **Call Stack**.
- Determine why a value is incorrect before changing the code.

## Test Order

Use this order as one of your tests:

- Product: **Wireless Mouse**
- Price: **$25.00**
- Quantity: **4**
- Discount: **10%**

When the application is working correctly, the calculations should be:

- Subtotal: **$100.00**
- Discount: **$10.00**
- Discounted merchandise total: **$90.00**
- Shipping: **$0.00**
- Tax: **$4.95**
- Final total: **$94.95**
- Saved quantity: **4**

If your results are different, use the debugger to determine where the values first become incorrect.

## What to Submit

Submit your corrected PHP files as directed by your instructor.

Also be prepared to explain at least two bugs you found:

- What was wrong?
- What value or behavior helped you identify the problem?
- Where did you place the breakpoint?
- Which debugger feature helped you?
- What change fixed the problem?

## Important

The goal is not simply to make the application work. The goal is to practice finding logic errors with a debugger.

Avoid adding `echo`, `var_dump()`, or `die()` statements as your primary debugging method. Use Xdebug to inspect the application while it is running.


## Database Naming Convention

Each table uses `ID` as its primary key column. Foreign keys use descriptive names such as `CustomerID` and `ProductID`.
