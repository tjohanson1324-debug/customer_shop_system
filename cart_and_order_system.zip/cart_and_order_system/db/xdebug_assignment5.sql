USE demo;


DROP VIEW IF EXISTS vCartTotal;
DROP TABLE IF EXISTS CartItem;
DROP TABLE IF EXISTS OrderItem; 
DROP TABLE IF EXISTS CustomerOrder; 
DROP TABLE IF EXISTS Customer;
DROP TABLE IF EXISTS Cart;
DROP TABLE IF EXISTS Product;


CREATE TABLE Cart(ID INT AUTO_INCREMENT PRIMARY KEY, ItemCount INT NOT NULL, Total DECIMAL (10,2) NOT NULL);

CREATE TABLE Customer(ID INT AUTO_INCREMENT PRIMARY KEY, Email VARCHAR(40) NOT NULL UNIQUE, Password VARCHAR(255) NOT NULL, FirstName VARCHAR(40) NOT NULL, LastName VARCHAR(40) NOT NULL, IsActive TINYINT(1) DEFAULT(1) NOT NULL, CartID int not null, FOREIGN KEY(CartID) REFERENCES Cart(ID));


CREATE TABLE Product(ID INT AUTO_INCREMENT PRIMARY KEY, ProductName VARCHAR(80) NOT NULL, DiscountPercent DECIMAL(5,2) NOT NULL, Price DECIMAL(8,2) NOT NULL);

CREATE TABLE CustomerOrder(ID INT AUTO_INCREMENT PRIMARY KEY, CartID INT NOT NULL, ItemCount Int NOT NULL, Subtotal DECIMAL(10,2) NOT NULL, Shipping DECIMAL(10,2) NOT NULL, Tax DECIMAL(10,2) NOT NULL, Total DECIMAL(10,2) NOT NULL, OrderDate DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP, FOREIGN KEY(CartID) REFERENCES Cart(ID));


CREATE TABLE CartItem(ID INT AUTO_INCREMENT PRIMARY KEY, ProductID INT NOT NULL, CartID INT NOT NULL, Quantity INT NOT NULL, Foreign KEY(ProductID) references Product(ID),  Foreign KEY(CartID) references Cart(ID));


CREATE TABLE OrderItem(ID INT AUTO_INCREMENT PRIMARY KEY, ProductID INT NOT NULL, Price DECIMAL (10,2) NOT NULL, CustomerOrderID INT NOT NULL, Quantity INT NOT NULL, Foreign KEY(ProductID) references Product(ID),  Foreign KEY(CustomerOrderID) references CustomerOrder(ID));

CREATE VIEW vCartTotal
AS
    SELECT c.ID, COALESCE(SUM(ci.Quantity),0) as'ItemCount', COALESCE(SUM(ci.Quantity * (p.Price - (p.Price * (p.DiscountPercent /100)))),0) as 'CartCostTotal' FROM Cart c
    LEFT JOIN CartItem ci on c.ID = ci.CartID
    LEFT JOIN Product p on ci.ProductID = p.ID
    Group BY c.ID
    ;


INSERT INTO Product(ProductName,Price,DiscountPercent) VALUES ('USB-C Cable',12.50,0),('Wireless Mouse',25.00,0),
('Mechanical Keyboard',79.95,0),('Webcam',49.99,0),('Laptop Stand',39.50,0),('USB Hub',31.25,0),('Headset',59.00,0),
('Portable SSD',89.99,0);
