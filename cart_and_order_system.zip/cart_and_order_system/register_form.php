
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
        <?php include_once('nav_bar.php') ?>
        <main>
            <form action="process/register_process.php" method="post">
                <label for="FirstName">FirstName</label>
                <input name="FirstName" required>
                <label for="LastName">LastName</label>
                <input name="LastName" required>
                <label for="Email">Email</label>
                <input name="Email" type="email" required>
                <label for="Password">Password</label>
                <input name="Password" type="Password" required>
                <button type="submit">Register</button>
            </form>
        </main>
</body>
</html>