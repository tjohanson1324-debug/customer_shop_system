<?php
require_once '../include/database.php';
require_once '../include/functions.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $CartID = (int)($_POST['cart_id'] ?? 0);
    $productID = (int)($_POST['product_id'] ?? 0);
    $ItemID = (int) ($_POST["item_id"]);
    $quantity = (int)($_POST['quantity'] ?? 1);

    $stmt = $db->prepare('SELECT ID, ProductName, Price FROM Product WHERE ID = :id');
    $stmt->execute(['id' => $productID]);
    $product = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$product) {
        exit('Product not found. Use the debugger to determine why.');
    }

    $price = (float)$product['Price'];

    $insert = $db->prepare('UPDATE CartItem
    SET 
    Quantity = :qty
    WHERE CartID = :ID AND ID = :ItemID
    '
    );
    $insert->execute([
        ':ID' => $CartID,
        ':qty' => $quantity,
        ':ItemID' => $ItemID
    ]);
    
    $sql = $db->prepare( 'SELECT * FROM vCartTotal WHERE ID = :cartID');
    $sql->execute([':cartID' => $CartID]);
    $CartTotals = $sql->fetch();

    $update = $db->prepare('UPDATE Cart
    SET Total = :total,
     ItemCount = :itemCount
    WHERE ID = :id');
    $update->execute([
        ':total' => $CartTotals['CartCostTotal'],
        ':itemCount' => $CartTotals['ItemCount'],
        ':id' => $CartID
    ]);

    header('Location: ../cart.php?customer_id=' . $CartID);
    exit;
}
header('Location: ../index.php');
