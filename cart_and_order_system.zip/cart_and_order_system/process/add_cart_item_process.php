<?php
require_once '../include/database.php';
require_once '../include/functions.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $CartID = (int)($_POST['cart_id'] ?? 0);
    $productID = (int)($_POST['product_id'] ?? 0);
    $quantity = (int)($_POST['quantity'] ?? 1);

    $stmt = $db->prepare('SELECT ID, ProductName, Price FROM Product WHERE ID = :id');
    $stmt->execute(['id' => $productID]);
    $product = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$product) {
        exit('Product not found. Use the debugger to determine why.');
    }

    $price = (float)$product['Price'];

    $queryCart = $db->prepare('SELECT * FROM CartItem WHERE CartID = :CartID AND ProductID = :ProductID');
    $queryCart->execute([
        ':CartID' => $CartID,
        ':ProductID' => $productID
    ]);
    $CartItems = $queryCart->fetch();
    if ($CartItems != null) {
        $update = $db->prepare(
            'UPDATE CartItem
    SET 
    Quantity = :qty
    WHERE CartID = :ID AND ID = :ItemID
    ' );
        $update->execute([
            ':ID' => $CartID,
            ':qty' => $CartItems['Quantity'] + $quantity,
            ':ItemID' => $CartItems['ID']
        ]);
    } else {
        $insert = $db->prepare('INSERT INTO CartItem (CartID, ProductID, Quantity) VALUES (:customer, :product, :qty)');
        $insert->execute([
            ':customer' => $CartID,
            ':product' => $productID,
            ':qty' => $quantity,
        ]);
    }

    $sql = $db->prepare('SELECT * FROM vCartTotal WHERE ID = :cartID');
    $sql->execute([':cartID' => $CartID]);
    $CartTotals = $sql->fetch();

    $update = $db->prepare('UPDATE Cart
    SET Total = :total,
     ItemCount = :itemCount
    WHERE ID = :id');
    $update->execute([
        ':total' => $CartTotals['CartCostTotal'],
        ':itemCount' => $CartTotals['ItemCount'],
        ':id' => $CartID
    ]);

    header('Location: ../cart.php?customer_id=' . $CartID);
    exit;
}
header('Location: ../index.php');
