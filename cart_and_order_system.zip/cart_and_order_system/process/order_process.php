<?php
require_once '../include/database.php';
require_once '../include/functions.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $CartID = (int)($_POST['cart_id'] ?? 0);
    $subtotal = (float) ($_POST['subtotal'] ?? 0);
    $ItemCount = (int) ($_POST['ItemCount'] ?? 0);
    $shipping = getShippingCost($subtotal);
    $tax = calculateTax($subtotal, 5.5);
    $grandTotal = $subtotal + $shipping + $tax;

    $insert = $db->prepare('INSERT INTO CustomerOrder (CartID, Subtotal, Shipping, Tax, Total, ItemCount) VALUES (:CartID, :subtotal, :shipping, :tax, :total, :itemCount)');
    $insert->execute([
        ':CartID' => $CartID,
        ':subtotal' => $subtotal,
        ':shipping' => $shipping,
        ':tax' => $tax,
        ':total' => $grandTotal,
        ':itemCount' => $ItemCount
    ]);
    $NewOrderID = $db -> lastInsertId();
    $insert -> closeCursor();
    
    $Copy = $db-> prepare('INSERT INTO OrderItem (CustomerOrderID, ProductID, Quantity, Price)
    SELECT :NewOrderID, ci.ProductID, ci.Quantity, p.Price - (p.Price * (p.DiscountPercent /100))
    FROM CartItem ci
    JOIN Product p ON ci.ProductID = p.ID
    WHERE ci.CartID = :ID
    ');
    $Copy ->execute([
        ':NewOrderID' =>$NewOrderID,
        ':ID' => $CartID
    ]);
    header('Location: ../order.php?order_id=' . $NewOrderID);
    exit;
}
header('Location: ../index.php');
