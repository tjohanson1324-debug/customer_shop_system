<?php 
if(session_status() === PHP_SESSION_NONE)
    session_start();
if(!isset($_SESSION['user_id']))
{
    header('Location: ../login_form.php');
    exit();
}
require_once __DIR__ . '/../include/database.php'; 
$stmt = $db->prepare('SELECT ID, Email, Password, IsActive FROM Customer WHERE ID = :ID');
$stmt -> execute([
    ':ID' => $_SESSION['user_id']
]);
$currentUser = $stmt -> fetch();
if(!$currentUser || (int) $currentUser['IsActive'] ==0)
    {
        session_destroy();
        header('Location: login_form.php');
        exit();
    }
?>