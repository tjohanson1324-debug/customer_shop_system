<?php
require_once __DIR__ . '/../include/database.php'; 
session_start();
if(isset($_SESSION['user_id']))
    {
         header("Location: ../cart.php?customer_id=".$_SESSION['user_id']);
        exit();
    }
$Email = $_POST['Email'];
$Password = $_POST['Password'];
$query = $db->prepare('SELECT * FROM Customer WHERE Email = :email');
$query->execute([
    ':email' => $Email,
]);
$Customer = $query->fetch();
if($Customer)
    {
        if((int) $Customer['IsActive'] === 0)
            {

            }
            elseif(password_verify($Password,$Customer['Password']))
                {
                    $_SESSION['user_id'] = $Customer['ID'];
                    header("Location: ../cart.php?customer_id=".$Customer['ID']);
                    exit();
                }
                else header('Location: ../login_form.php');
    }
else
    header('Location: ../login_form.php');