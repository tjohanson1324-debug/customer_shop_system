<?php
require_once '../database.php';
require_once '../functions.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $discountPercent = (float)($_POST['discount'] ?? 0);

    $price = (float) ($_POST['price'] ?? 0);
    $ProductName = ($_POST['productName'] ?? 0);

    $insert = $db->prepare('INSERT INTO Product (ProductName, Price, DiscountPercent) VALUES (:ProductName, :Price, :DiscountPercent)');
    $insert->execute([
        ':ProductName' => $ProductName,
        ':Price' => $price,
        ':DiscountPercent' => $discountPercent,
    ]);

    header('Location: ../index.php');
    exit;
}
header('Location: ../index.php');
