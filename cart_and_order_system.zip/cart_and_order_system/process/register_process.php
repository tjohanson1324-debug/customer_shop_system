<?php
require_once('../include/database.php');
    $Email = $_POST['Email'];
    $Password = password_hash($_POST['Password'],PASSWORD_DEFAULT);
    $FirstName = $_POST['FirstName'];
    $LastName = $_POST['LastName'];
    
    $insert_Cart = $db->prepare('INSERT INTO Cart (ItemCount, Total) 
    VALUES(0,0)
    ');
    $insert_Cart ->execute();
    $CartID = $db -> lastInsertId();
    $insert_Cart -> closeCursor();

    $insert_customer = $db-> prepare('INSERT INTO Customer (FirstName, LastName, Email, Password,CartID) 
    VALUES(:firstName, :lastName, :email, :password, :cartID)');
    $insert_customer -> execute([
        ':firstName' => $FirstName,
        ':lastName' => $LastName,
        ':email' => $Email,
        ':password' => $Password,
        ':cartID' => $CartID
    ]);
    $insert_customer-> closeCursor()
 ?>