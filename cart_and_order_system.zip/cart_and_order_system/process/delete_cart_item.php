<?php
require_once '../include/database.php';
require_once '../include/functions.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $CartID = (int)($_POST['cart_id'] ?? 0);
    $ItemID = (int) ($_POST['item_id'] ?? 0);

    $delete = $db->prepare('DELETE FROM CartItem WHERE CartID = :CartID AND ID = :ID');
    $delete->execute([
        ':CartID' => $CartID,
        ':ID' => $ItemID
    ]);

     $sql = $db->prepare( 'SELECT * FROM vCartTotal WHERE ID = :cartID');
    $sql->execute([':cartID' => $CartID]);
    $CartTotals = $sql->fetch();

    $update = $db->prepare('UPDATE Cart
    SET Total = :total,
     ItemCount = :itemCount
    WHERE ID = :id');
    $update->execute([
        ':total' => $CartTotals['CartCostTotal'],
        ':itemCount' => $CartTotals['ItemCount'],
        ':id' => $CartID
    ]);

    header('Location: cart.php?customer_id=' . $CartID);
    exit;
}
header('Location: ../index.php');
