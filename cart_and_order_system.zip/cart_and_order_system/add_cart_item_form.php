<?php
require_once 'include/database.php';
$products = $db->query('SELECT ID, ProductName, Price FROM Product ORDER BY ProductName')->fetchAll(PDO::FETCH_ASSOC);
$orderID = $_POST['id']
?>
<!doctype html>
<html>

<head>
    <meta charset="utf-8">
    <title>Xdebug Order Lab</title>
    <link rel="stylesheet" href="style.css">
</head>

<body>
    <main>
        <h1>Customer Cart and Order System</h1>
        <form method="post" action="process/add_cart_item_process.php">
            <label>Product <select name="product_id">
                    <?php foreach ($products as $p): ?><option value="<?= $p['ID'] ?>"><?= htmlspecialchars($p['ProductName']) ?> ($<?= number_format($p['Price'], 2) ?>)</option><?php endforeach; ?>
                </select></label>
            <label>Quantity <input type="number" name="quantity" value="2" min="1" max="20" required></label>
            <input type="hidden" value="<?php echo($orderID) ?>" name="cart_id">
            <button type="submit">Add</button>
        </form>
    </main>
</body>

</html>