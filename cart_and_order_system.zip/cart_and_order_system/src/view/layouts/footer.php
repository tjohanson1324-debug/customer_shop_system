</main>
<footer><p>Customer Order And Cart System</p></footer>
</body>
</html>