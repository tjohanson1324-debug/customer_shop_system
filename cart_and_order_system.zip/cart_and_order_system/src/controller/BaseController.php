<?php
enum userRole
{
    case admin;
    case customer;
}
    class BaseController
    {
        function requireRole(userRole $requiredRole)
        {
            $userRole = $_SESSION['user_role'] ?? userRole::customer;
            if($userRole != $requiredRole)
                {
                    http_response_code(403);
                    $title = "Access Denied";
                    require_once __DIR__ .'/../view/layouts/header.php';
                    
                }
        }
    }
 ?>