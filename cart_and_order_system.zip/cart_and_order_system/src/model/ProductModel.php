<?php
class ProductModel
{
    private $db;
    public function __construct(PDO $databaseConnection)
    {
        $this->db = $databaseConnection;
    }
    public function AddProduct(string $ProductName, float $discountPercent, float $price)
    {
        $insert = $this->db->prepare('INSERT INTO Product (ProductName, Price, DiscountPercent) VALUES (:ProductName, :Price, :DiscountPercent)');
       return $insert->execute([
            ':ProductName' => $ProductName,
            ':Price' => $price,
            ':DiscountPercent' => $discountPercent,
        ]);
    }
    public function EditProduct()
}
