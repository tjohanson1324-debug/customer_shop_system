<?php

include_once 'database.php';
function get_orders()
{
    global $db;
    $sql = $db->prepare('SELECT u.FirstName,u.LastName, o.* FROM CustomerOrder o
JOIN Cart ct ON o.CartID = ct.ID
JOIN User u  ON u.ID = ct.UserID
ORDER BY u.ID DESC');
    $sql->execute();
    $orders = $sql->fetchAll();
    return $orders;
}
function get_order_items(int $orderID)
{
    global $db;
    $sql = $db->prepare('SELECT o.*, oi.Price, p.ProductName, oi.Quantity, p.DiscountPercent, o.Total FROM CustomerOrder o
JOIN Cart ct ON o.CartID = ct.ID
JOIN OrderItem oi ON o.ID = oi.CustomerOrderID
JOIN Product p ON oi.ProductID = p.ID
Where o.ID = :ID');
    $sql->execute([
        ':ID' => $orderID
    ]);
    $orderItems = $sql->fetchAll();
    return $orderItems;
}

function add_Order(int $cartID, float $subtotal, float $shipping, float $tax, float $total, int $itemCount)
{
    global $db;
    $sql = $db->prepare('INSERT INTO CustomerOrder (CartID, Subtotal, Shipping, Tax, Total, ItemCount) 
    VALUES (:cartID, :subtotal, :shipping, :tax, :total, :itemCount)');
    $sql->execute([
        ':cartID' => $cartID,
        'subtotal' => $subtotal,
        ':shipping' => $shipping,
        ':tax' => $tax,
        ':total' => $total,
        ':itemCount' => $itemCount
    ]);
    $id = $db -> lastInsertId();
    $sql -> closeCursor();
    return $id;
}
