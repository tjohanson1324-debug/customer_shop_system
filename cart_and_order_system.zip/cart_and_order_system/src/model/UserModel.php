<?php

include_once('database.php');

class UserModel
{
    private PDO $db;
    public function __construct(PDO $databaseConnection)
    {
        $this->db = $databaseConnection;
    }
    public function createUser(int $email, string $password, string $firstName, string $lastName, userRole $role = userRole::customer)
    {
            $passwordHash = password_hash($password, PASSWORD_BCRYPT);
            $sql = $this->db->prepare('INSERT INTO User (FirstName, LastName, Email, Password, Role) 
    VALUES(:firstName, :lastName, :email, :password, :role)');
            $sql->execute([
                ':firstName' => $firstName,
                ':lastName' => $lastName,
                ':role' => $role != null ? $role : 'customer',
                ':email' => $email,
                ':password' => $passwordHash
            ]);
          return $this->db->lastInsertId();
    }
   public function findByEmail(string $email)
    {
        $sql = $this->db->prepare('SELECT * FROM User WHERE Email = :email');
        $sql->execute([':email' => $email]);
        $user = $sql->fetch();
        return $user;
    }
    /**
     *Remove a terminated user.
     @param $userID User to remove.
     */
   public function removeUser(int $userID)
    {
       $sql = $this->db->prepare('DELETE FROM User WHERE ID = :id');
        $sql->execute([':id'=>$userID]);
    }
    public function getAllUsers()
    {
         $sql = $this->db->prepare('SELECT * FROM User');
        $sql->execute();
        $users = $sql->fetchAll();
        return $users;
    }
}
