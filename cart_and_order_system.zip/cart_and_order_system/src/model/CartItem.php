<?php
class CartItem
{
    private int $productID;
    private string $productName;
    private float $price;
    private int $quantity;

    public function __construct(int $productID, string $productName, float $price, int $quantity)
    {
        $this->productID = $productID;
        $this->productName = $productName;
        $this->price = $price;
        $this->quantity = $quantity;
    }
    public function getSubtotal()
    {
        return $this->price * $this->quantity;
    }
    public function getProductID()
    {
        return $this->productID;
    }
    public function getProductName()
    {
        return $this->productName;
    }
    public function getPrice()
    {
        return $this->price;
    }
    public function getQuantity()
    {
        return $this->quantity;
    }
}
?>
