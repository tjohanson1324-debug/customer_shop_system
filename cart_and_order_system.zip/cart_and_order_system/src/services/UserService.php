<?php


class UserService
{
    private $userModel;
    public function __construct(UserModel $userModel)
    {
        $this->userModel = $userModel;
    }
    public function register($email, $password, $firstName, $lastName)
    {
        if (!$this->userModel->findByEmail($email)) {
            $hassedPassword = password_hash($password, PASSWORD_DEFAULT);
            $this->userModel->createUser($email, $hassedPassword, $firstName, $lastName);
        } else
            throw new Exception('An account with is email allready exists.');
        }
    }
}
