USE demo;


DROP VIEW IF EXISTS vCartTotal;
DROP VIEW IF EXISTS vCartDetails;
DROP PROCEDURE IF EXISTS spModifyCartItem;
DROP TABLE IF EXISTS CartItem;
DROP TABLE IF EXISTS OrderItem; 
DROP TABLE IF EXISTS CustomerOrder; 
DROP TABLE IF EXISTS UserSession;
DROP TABLE IF EXISTS Cart;
DROP TABLE IF EXISTS User;
DROP TABLE IF EXISTS Product;



CREATE TABLE User(ID INT AUTO_INCREMENT PRIMARY KEY, Email VARCHAR(40) NULL UNIQUE, Password VARCHAR(255) NULL, 
FirstName VARCHAR(40) NULL, LastName VARCHAR(40) NULL, GuestToken VARCHAR(64) NULL UNIQUE,
Role ENUM('guest','customer','admin') NOT NULL DEFAULT 'customer');


CREATE TABLE Cart(ID INT AUTO_INCREMENT PRIMARY KEY, UserID INT NOT NULL UNIQUE, 
CONSTRAINT fk_user_cart FOREIGN KEY(UserID) REFERENCES User(ID) ON DELETE CASCADE);

CREATE TABLE UserSession (SessionID VARCHAR(255) PRIMARY KEY, UserID INT NOT NULL, 
LastActivity DATETIME NOT NULL, FOREIGN KEY (UserID) REFERENCES User(ID) ON DELETE CASCADE);

CREATE TABLE Product(ID INT AUTO_INCREMENT PRIMARY KEY, ProductName VARCHAR(80) NOT NULL,
 DiscountPercent DECIMAL(5,2) NOT NULL, Price DECIMAL(8,2) NOT NULL);

CREATE TABLE CustomerOrder(ID INT AUTO_INCREMENT PRIMARY KEY, CartID INT NOT NULL, ItemCount Int NOT NULL, 
Subtotal DECIMAL(10,2) NOT NULL, Shipping DECIMAL(10,2) NOT NULL, Tax DECIMAL(10,2) NOT NULL, Total DECIMAL(10,2) NOT NULL, 
OrderDate DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP, FOREIGN KEY(CartID) REFERENCES Cart(ID));


CREATE TABLE CartItem(ID INT AUTO_INCREMENT PRIMARY KEY, ProductID INT NOT NULL, CartID INT NOT NULL, 
Quantity INT NOT NULL, Foreign KEY(ProductID) references Product(ID),  Foreign KEY(CartID) references Cart(ID));


CREATE TABLE OrderItem(ID INT AUTO_INCREMENT PRIMARY KEY, ProductID INT NOT NULL, Price DECIMAL (10,2) NOT NULL, 
CustomerOrderID INT NOT NULL, Quantity INT NOT NULL, Foreign KEY(ProductID) references Product(ID),  
Foreign KEY(CustomerOrderID) references CustomerOrder(ID));

CREATE VIEW vCartTotal
AS
    SELECT c.ID, COALESCE(SUM(ci.Quantity),0) as'ItemCount', 
    COALESCE(SUM(ci.Quantity * (p.Price - (p.Price * (p.DiscountPercent /100)))),0) as 'CartCostTotal' FROM Cart c
    LEFT JOIN CartItem ci on c.ID = ci.CartID
    LEFT JOIN Product p on ci.ProductID = p.ID
    Group BY c.ID
    ;
CREATE VIEW vCartDetails
AS
    SELECT c.ID as 'CartID', c.UserID as 'UserID',
            ci.ProductID as 'ProductID', ci.Quantity,
            p.ProductName, p.Price , (ci.Quantity * p.Price) AS Subtotal
        FROM Cart c
        JOIN CartItem ci ON c.ID = ci.CartID
        JOIN Product p ON ci.ProductID = p.ID;
DELIMITER  //
CREATE PROCEDURE spModifyCartItem(
    IN p_cart_id INT,
    IN p_product_id INT,
    IN p_quantity INT
)
BEGIN
    IF  p_quantity <= 0 THEN 
        DELETE FROM CartItem
        WHERE CartID = p_cart_id AND ProductID = p_product_id;
    ELSE
        INSERT INTO CartItem (ProductID, CartID, Quantity)
        VALUES (p_product_id, p_cart_id, p_quantity)
        ON DUPLICATE KEY UPDATE Quantity = p_quantity;
    END IF;
END //
DELIMITER ;

INSERT INTO Product(ProductName,Price,DiscountPercent) VALUES ('USB-C Cable',12.50,0),('Wireless Mouse',25.00,0),
('Mechanical Keyboard',79.95,0),('Webcam',49.99,0),('Laptop Stand',39.50,0),('USB Hub',31.25,0),('Headset',59.00,0),
('Portable SSD',89.99,0);
INSERT INTO User(Email, Password, FirstName, LastName) VALUES ('Test@a.com','123','Test','Test');
INSERT INTO Cart (UserID) VALUES (1);
INSERT INTO CartItem (ProductID, CartID, Quantity) VALUES (1,1,1);
