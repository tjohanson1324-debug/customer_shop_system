<?php
require_once 'include/database.php';
?>
<!doctype html>
<html>

<head>
    <meta charset="utf-8">
    <title>Xdebug Order Lab</title>
    <link rel="stylesheet" href="style.css">
</head>

<body>
        <?php include_once('nav_bar.php') ?>
    <main>
        <h1>Customer Cart and Order System</h1>
        <form method="post" action="process/add_product_process.php">
            <label>Name<input type="text" required name="productName"></label>
            <label>Price<input type="number" step="0.01" name="price" value="25" min="1" max="5000" i required></label>
            <label>Discount % <input type="number" name="discount" value="10" min="0" max="50"></label>
            <button type="submit">Add</button>
        </form>
        <p><a href="carts.php">View Carts</a></p>
    </main>
</body>

</html>