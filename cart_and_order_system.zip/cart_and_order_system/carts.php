<?php require_once 'include/database.php';
$sql = 'SELECT ct.ID, c.FirstName,c.LastName, ct.ItemCount, ct.Total FROM Cart ct
JOIN Customer c ON ct.ID=c.ID 
ORDER BY ct.ID DESC';
$orders = $db->query($sql)->fetchAll(PDO::FETCH_ASSOC);
?>
<!doctype html>
<html>

<head>
    <meta charset="utf-8">
    <title>Orders</title>
    <link rel="stylesheet" href="style.css">
</head>

<body>
        <?php include_once('nav_bar.php') ?>

    <main>
        <h1>Carts</h1>
        <table>
            <tr>
                <th>ID</th>
                <th>Customer</th>
                <th>Item Count</th>
                <th>Total</th>
                <th>Actions</th>
            </tr><?php foreach ($orders as $o): ?>
                <tr>
                    <td><?= $o['ID'] ?></td>
                    <td><?= htmlspecialchars($o['FirstName'] . ' ' . $o['LastName']) ?></td>
                    <td><?= $o['ItemCount'] ?></td>
                    <td>$<?= number_format($o['Total'], 2) ?></td>
                    <td>
                        <form action="cart.php" method="get">
                            <input value="<?php echo($o['ID']) ?>" name="customer_id" hidden>
                            <button type="submit">View</button>
                        </form>
                    </td>
                </tr><?php endforeach; ?>
        </table>
        <p><a href="index.php">Back</a></p>
    </main>
</body>

</html>