<?php
require_once 'include/database.php';
?>
<!doctype html>
<html>

<head>
    <meta charset="utf-8">
    <title>Xdebug Order Lab</title>
    <link rel="stylesheet" href="style.css">
</head>

<body>
        <?php include_once('nav_bar.php') ?>
    <main>
        <h1>Customer Order System</h1>
        <form method="get" action="cart.php">
            <label>Customer <select name="customer_id">
                    <?php foreach ($db->query('SELECT ID, FirstName, LastName FROM Customer ORDER BY LastName') as $c): ?>
                        <option value="<?= $c['ID'] ?>"><?= htmlspecialchars($c['FirstName'] . ' ' . $c['LastName']) ?></option>
                    <?php endforeach; ?>
                </select></label>
            <button type="submit">Open Cart</button>
        </form>
        
        <p><a href="carts.php">View Carts</a></p>
        <p><a href="orders.php">View Orders</a></p>
        <p><a href="add_product_form.php">Add Products</a></p>
    </main>
</body>

</html>