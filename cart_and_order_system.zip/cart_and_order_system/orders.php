<?php require_once 'include/database.php';
$sql = 'SELECT c.FirstName,c.LastName, o.* FROM CustomerOrder o
JOIN Cart ct ON o.CartID = ct.ID
JOIN Customer c ON ct.ID = c.CartID
ORDER BY c.ID DESC';
$orders = $db->query($sql)->fetchAll(PDO::FETCH_ASSOC);
$ColumnNames = ['First Name', 'Last Name', 'Item Count', 'Subtotal', 'Shipping', 'Tax', 'Total']
?>
<!doctype html>
<html>

<head>
    <meta charset="utf-8">
    <title>Orders</title>
    <link rel="stylesheet" href="style.css">
</head>

<body>
        <?php include_once('nav_bar.php') ?>
    <main>
        <h1>Orders</h1>
        <table>
            <tr>
                <?php foreach ($ColumnNames as $ColumnName): ?>
                    <th><?php echo ($ColumnName) ?></th>
                <?php endforeach; ?>
            </tr>
            <?php foreach ($orders as $o): ?>
                <tr>
                    <?php foreach ($ColumnNames as $ColumnName): ?>
                        <td>
                            <?php
                                $data = $o[ str_replace(' ', '',$ColumnName)];
                                echo($data)
                             ?>
                        </td>
                    <?php endforeach; ?>
                    <td>
                        <form action="order.php" method="get">
                            <input name="order_id" value="<?php echo $o['ID']?>" hidden>
                            <button type="submit">View</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; ?>
        </table>
        <p><a href="index.php">Back</a></p>
    </main>
</body>

</html>