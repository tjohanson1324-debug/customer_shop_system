<?php require_once 'process/auth.php';
$customerID = $currentUser['ID'];

$sql = 'SELECT ci.*, p.ProductName, p.Price, p.DiscountPercent from Cart ct
join CartItem ci on ct.ID = ci.CartID
join Product p on p.ID = ci.ProductID
 Where ct.ID = :ID
ORDER BY ci.ID DESC';
$stmt = $db->prepare($sql);
$stmt->execute([':ID' => $customerID]);
$CartItems = $stmt->fetchAll(PDO::FETCH_ASSOC);
$sql = 'SELECT * FROM vCartTotal WHERE ID = :id';
$stmt1 = $db->prepare($sql);
$stmt1->execute([':id' => $customerID]);
$CartTotals = $stmt1->fetch();

?>
<!doctype html>
<html>

<head>
    <meta charset="utf-8">
    <title>Xdebug Order Lab</title>
    <link rel="stylesheet" href="style.css">
</head>

<body>
    <?php include_once('nav_bar.php') ?>
    <main>
        <h1>Cart</h1>
        <form method="post" action="add_cart_item_form.php">
            <input Value="<?php echo ($customerID) ?>" name="id" hidden>
            <button type="submit">Add Item</button>
        </form>
        <h1>Items</h1>
        <div class="product-container">
            <?php foreach ($CartItems as $ci): ?>
                <article class="product">
                    <div class="card-content">
                        <h3> <?= $ci['ProductName'] ?> </h3>
                        <div>
                            <p>$<?= number_format($ci['Price'] * $ci['Quantity'],2) ?></p>
                            <form action="process/edit_cart_item_process.php" method="post">
                                <input name="product_id" hidden value="<?= $ci['ProductID'] ?>">
                                <input name="quantity" type="number" max ="50" min = "1"required value="<?= $ci['Quantity'] ?>">
                                <input name="cart_id" value="<?= $customerID ?>" hidden>
                                <input name="item_id" value="<?= $ci['ID'] ?>" hidden>
                                <button type="submit">Save</button>
                            </form>
                        </div>
                    </div>
                </article>
            <?php endforeach; ?>
        </div>
        <table>
            <tr>
                <th>
                    Items
                </th>
                <th>
                    Total
                </th>
            </tr>
            <tr>
                <td>
                    <?php echo ($CartTotals['ItemCount'])  ?>
                </td>
                <td>
                    $<?php echo (number_format($CartTotals['CartCostTotal'], 2)) ?>
                </td>
            </tr>
        </table>
        <form method="post" action="process/order_process.php">
            <input value="<?php echo ($CartTotals['CartCostTotal']) ?>" name="subtotal" hidden>
            <input value="<?php echo ($customerID) ?>" name="cart_id" hidden>
            <input value="<?php echo ($CartTotals['ItemCount']) ?>" name="ItemCount" hidden>
            <button type="submit" <?php if ($CartTotals['CartCostTotal'] <= 0) echo ('hidden') ?>>Buy</button>
        </form>
    </main>
</body>

</html>