<?php require_once 'database.php';
$OrderID = $_GET['id'];
$sql = 'SELECT oi.*, p.ProductName, p.Price from OrderItem o
join OrderItem oi on o.ID = oi.CustomerOrderID
join Product p on p.ID = oi.ProductID
 Where o.ID = :ID
ORDER BY o.ID DESC';
$stmt = $db -> prepare($sql);
$stmt->execute([':ID' => $OrderID]);
$orderItems = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<!doctype html>
<html>

<head>
    <meta charset="utf-8">
    <title>Orders</title>
    <link rel="stylesheet" href="style.css">
</head>

<body>
    <main>
        <h1>Items</h1>
        <table>
            <tr>
                <th>ID</th>
                <th>Product Name</th>
                <th>Quantity</th>
                <th>Price</th>
            </tr><?php foreach ($orderItems as $oi): ?>
                <tr>
                    <td><?= $oi['ID'] ?></td>
                    <td><?= htmlspecialchars($oi['ProductName']) ?></td>
                    <td><?= $oi['Quantity'] ?></td>
                    <td><?= number_format($oi['Price'], 2) ?></td>
                </tr><?php endforeach; ?>
        </table>
        <p><a href="index.php">New Order</a></p>
    </main>
</body>

</html>