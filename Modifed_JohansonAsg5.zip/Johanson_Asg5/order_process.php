<?php
require_once 'database.php';
require_once 'functions.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $customerID = (int)($_POST['customer_id'] ?? 0);
    $productID = (int)($_POST['product_id'] ?? 0);
    $quantity = (int)($_POST['quantity'] ?? 1);
    $discountPercent = (float)($_POST['discount'] ?? 0);

    $stmt = $db->prepare('SELECT ID, ProductName, Price FROM Product WHERE ID = :id');
    $stmt->execute(['id' => $productID]);
    $product = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$product) {
        exit('Product not found. Use the debugger to determine why.');
    }

    $price = (float)$product['Price'];
    $subtotal = $price * $quantity;
    $discountedTotal = calculateOrderTotal($price, $quantity, $discountPercent);
    $shipping = getShippingCost($subtotal);
    $tax = calculateTax($discountedTotal, 5.5);
    $grandTotal = $discountedTotal + $shipping + $tax;

    $insert = $db->prepare('INSERT INTO CustomerOrder (CustomerID, ProductID, Quantity, DiscountPercent, Subtotal, Shipping, Tax, Total) VALUES (:customer, :product, :qty, :discount, :subtotal, :shipping, :tax, :total)');
    $insert->execute([
        'customer' => $customerID,
        'product' => $productID,
        'qty' => $quantity,
        'discount' => $discountPercent,
        'subtotal' => $subtotal,
        'shipping' => $shipping,
        'tax' => $tax,
        'total' => $grandTotal
    ]);

    header('Location: order_complete.php?id=' . $db->lastInsertId());
    exit;
}
header('Location: index.php');
