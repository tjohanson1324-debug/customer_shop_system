<?php require_once 'database.php';
$sql = 'SELECT o.ID,o.OrderDate,c.FirstName,c.LastName, o.ItemCount, o.Total, o.Tax FROM CustomerOrder o 
JOIN Customer c ON o.CustomerID=c.ID 
ORDER BY o.ID DESC';
$orders = $db->query($sql)->fetchAll(PDO::FETCH_ASSOC);
?>
<!doctype html>
<html>

<head>
    <meta charset="utf-8">
    <title>Orders</title>
    <link rel="stylesheet" href="style.css">
</head>

<body>
    <main>
        <h1>Orders</h1>
        <table>
            <tr>
                <th>ID</th>
                <th>Customer</th>
                <th>Item Count</th>
                <th>Tax</th>
                <th>Total</th>
                <th>Actions</th>
            </tr><?php foreach ($orders as $o): ?><tr>
                    <td><?= $o['ID'] ?></td>
                    <td><?= htmlspecialchars($o['FirstName'] . ' ' . $o['LastName']) ?></td>>
                    <td><?= $o['ItemCount'] ?></td>
                    <td>$<?= number_format($o['Tax'], 2) ?></td>
                    <td>$<?= number_format($o['Total'], 2) ?></td>
                    <td><a href="order_items.php?id=<?php echo($o['ID']) ?>">View Order</a></td>
                </tr><?php endforeach; ?>
        </table>
        <p><a href="index.php">New Order</a></p>
    </main>
</body>

</html>