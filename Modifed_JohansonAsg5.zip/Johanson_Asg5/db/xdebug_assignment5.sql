USE demo;

 DROP TABLE IF EXISTS OrderItem; 
DROP TABLE IF EXISTS Product;
DROP TABLE IF EXISTS CustomerOrder; 
DROP TABLE IF EXISTS Customer;
CREATE TABLE Customer(ID INT AUTO_INCREMENT PRIMARY KEY, FirstName VARCHAR(40) NOT NULL, LastName VARCHAR(40) NOT NULL);


CREATE TABLE Product(ID INT AUTO_INCREMENT PRIMARY KEY, ProductName VARCHAR(80) NOT NULL, Price DECIMAL(8,2) NOT NULL);


CREATE TABLE CustomerOrder(ID INT AUTO_INCREMENT PRIMARY KEY, CustomerID INT NOT NULL, ItemCount Int NOT NULL, Subtotal DECIMAL(10,2) NOT NULL, Shipping DECIMAL(10,2) NOT NULL, Tax DECIMAL(10,2) NOT NULL, Total DECIMAL(10,2) NOT NULL, OrderDate DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP, FOREIGN KEY(CustomerID) REFERENCES Customer(ID));


CREATE TABLE OrderItem(ID INT AUTO_INCREMENT PRIMARY KEY, ProductID INT NOT NULL, CustomerOrderID INT NOT NULL, Quantity INT NOT NULL, DiscountPercent DECIMAL(5,2) NOT NULL, Foreign KEY(ProductID) references Product(ID),  Foreign KEY(CustomerOrderID) references CustomerOrder(ID));

INSERT INTO Customer(FirstName,LastName) VALUES ('Andy','Johnson'),('Maria','Lopez'),('Jordan','Lee'),('Sam','Patel'),('Taylor','Brown');
INSERT INTO Product(ProductName,Price) VALUES ('USB-C Cable',12.50),('Wireless Mouse',25.00),('Mechanical Keyboard',79.95),('Webcam',49.99),('Laptop Stand',39.50),('USB Hub',31.25),('Headset',59.00),('Portable SSD',89.99);
INSERT INTO CustomerOrder(CustomerID, ItemCount, Subtotal, Shipping, Tax, Total) VALUES (1,2,50,0,10.5,60.5);
INSERT INTO OrderItem(ProductID, CustomerOrderID, Quantity, DiscountPercent) VALUES (1,1,1,0), (2,1,1,0);
