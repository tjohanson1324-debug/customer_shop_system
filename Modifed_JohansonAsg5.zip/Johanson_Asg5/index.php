<?php
require_once 'database.php';
$products = $db->query('SELECT ID, ProductName, Price FROM Product ORDER BY ProductName')->fetchAll(PDO::FETCH_ASSOC);
$sql = 'SELECT o.ID,o.OrderDate,c.FirstName,c.LastName, o.ItemCount, o.Total, o.Tax FROM CustomerOrder o 
JOIN Customer c ON o.CustomerID=c.ID 
ORDER BY o.ID DESC'
?>
<!doctype html>
<html>

<head>
    <meta charset="utf-8">
    <title>Xdebug Order Lab</title>
    <link rel="stylesheet" href="style.css">
</head>

<body>
    <main>
        <h1>Customer Order System</h1>
        <form method="post" action="order_process.php">
            <label>Customer <select name="customer_id">
                    <?php foreach ($db->query('SELECT ID, FirstName, LastName FROM Customer ORDER BY LastName') as $c): ?>
                        <option value="<?= $c['ID'] ?>"><?= htmlspecialchars($c['FirstName'] . ' ' . $c['LastName']) ?></option>
                    <?php endforeach; ?>
                </select></label>
            <button type="submit">Place Order</button>
        </form>
        <form method="post" action="add_item_form.php">
        
             <button type="submit">Add Item</button>
        </form>
        <p><a href="orders.php">View Orders</a></p>
    </main>
</body>

</html>