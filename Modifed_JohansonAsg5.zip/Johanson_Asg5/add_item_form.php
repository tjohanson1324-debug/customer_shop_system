<?php
require_once 'database.php';
$products = $db->query('SELECT ID, ProductName, Price FROM Product ORDER BY ProductName')->fetchAll(PDO::FETCH_ASSOC);
$orderID = $_GET['id']
?>
<!doctype html>
<html>

<head>
    <meta charset="utf-8">
    <title>Xdebug Order Lab</title>
    <link rel="stylesheet" href="style.css">
</head>

<body>
    <main>
        <h1>Customer Order System</h1>
        <form method="post" action="add_item_process.php">
            <label>Product <select name="product_id">
                    <?php foreach ($products as $p): ?><option value="<?= $p['ID'] ?>"><?= htmlspecialchars($p['ProductName']) ?> ($<?= number_format($p['Price'], 2) ?>)</option><?php endforeach; ?>
                </select></label>
            <label>Quantity <input type="number" name="quantity" value="2" min="1" max="20" required></label>
            <label>Discount % <input type="number" name="discount" value="10" min="0" max="50"></label>
            <input type="hidden" value="<?php echo($orderID) ?>">
            <button type="submit">Add</button>
        </form>
        <p><a href="orders.php">View Orders</a></p>
    </main>
</body>

</html>