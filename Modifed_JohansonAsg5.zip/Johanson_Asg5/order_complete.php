<?php
require_once 'database.php';
$id = (int)($_GET['id'] ?? 0);
$stmt = $db->prepare('SELECT o.*, c.FirstName, c.LastName, p.ProductName FROM CustomerOrder o JOIN Customer c ON o.CustomerID=c.ID JOIN Product p ON o.ProductID=p.ID WHERE o.ID=:id');
$stmt->execute(['id' => $id]);
$o = $stmt->fetch(PDO::FETCH_ASSOC);
$discount = number_format($o['Subtotal'] * ($o['DiscountPercent'] /100),2);
?>
<!doctype html>
<html>

<head>
    <meta charset="utf-8">
    <title>Order Complete</title>
    <link rel="stylesheet" href="style.css">
</head>

<body>
    <main>
        <h1>Order Complete</h1><?php if ($o): ?><p>Customer: <?= htmlspecialchars($o['FirstName'] . ' ' . $o['LastName']) ?></p>
            <p>Product: <?= htmlspecialchars($o['ProductName']) ?></p>
            <p>Quantity: <?= $o['Quantity'] ?></p>
            <p>Subtotal: $<?= number_format($o['Subtotal'], 2) ?></p>
            <p>Discount: $<?= $discount ?></p>
            <p>Discounted Total: $<?= number_format($o['Subtotal'] - $discount,2) ?> </p>
            <p>Shipping: $<?= number_format($o['Shipping'], 2) ?></p>
            <p>Tax: $<?= number_format($o['Tax'], 2) ?></p>
            <p><strong>Total: $<?= number_format($o['Total'], 2) ?></strong></p><?php else: ?><p>Order not found.</p><?php endif; ?><p><a href="index.php">New Order</a> | <a href="orders.php">Orders</a></p>
    </main>
</body>

</html>