<?php
require_once 'database.php';
require_once 'functions.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $customerID = (int)($_POST['order_id'] ?? 0);
    $productID = (int)($_POST['product_id'] ?? 0);
    $quantity = (int)($_POST['quantity'] ?? 1);
    $discountPercent = (float)($_POST['discount'] ?? 0);

    $stmt = $db->prepare('SELECT ID, ProductName, Price FROM Product WHERE ID = :id');
    $stmt->execute(['id' => $productID]);
    $product = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$product) {
        exit('Product not found. Use the debugger to determine why.');
    }

    $price = (float)$product['Price'];

    $insert = $db->prepare('INSERT INTO OrderItem (CustomerOrderID, ProductID, Quantity, DiscountPercent) VALUES (:customer, :product, :qty, :discount)');
    $insert->execute([
        'customer' => $customerID,
        'product' => $productID,
        'qty' => $quantity,
        'discount' => $discountPercent
    ]);

    header('Location: order_complete.php?id=' . $db->lastInsertId());
    exit;
}
header('Location: index.php');
