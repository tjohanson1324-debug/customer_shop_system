<?php
include_once __DIR__ . '/../model/EmployeeModel.php';
include __DIR__ . '/../model/OrderModel.php';
include_once __DIR__ . '/../services/EmployeeService.php';

$action = filter_input(INPUT_GET, 'action');
if ($action == null)
    $action = filter_input(INPUT_POST, 'action');
if ($action == null)
    $action = 'list_orders';
$employeeModel = new EmployeeModel($db);
$employeeService = new EmployeeService($employeeModel);
$orderModel = new OrderModel($db);
if (!$employeeService->isLoggedIn())
    header("Location: ../auth_manager/");
else
    $user = $employeeService->getCurrentEmployee();
switch ($action) {
    case 'list_orders':
        $orders = $orderModel->getOrders();
        include_once('order_list.php');
        break;
    case 'view_order':
        $orderID = $_GET['order_id'];
        $orderItems = $orderModel->getOrderItems($orderID);
        $orderTotals = $orderModel->getOrderByID($orderID);
        include_once('order_details.php');
        break;
    default:
        echo 'unknown action';
        break;
}
