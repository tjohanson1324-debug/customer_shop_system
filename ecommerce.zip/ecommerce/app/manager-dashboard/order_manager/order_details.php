<?php include_once '../view/header.php';
$columnNames = ['Product Name', 'Price', 'Quantity'];
?>
<table>
    <tr>
        <?php foreach ($columnNames as $columnName): ?>
            <th><?= $columnName ?></th>
        <?php endforeach ?>
    </tr>
    <?php foreach ($orderItems as $orderItem): ?>
        <tr>
            <?php foreach ($columnNames as $columnName): ?>
                <td>
                    <div>
                        <?php
                        $data = $orderItem[str_replace(' ', '', $columnName)];
                        if ($data !== null)
                            echo $data;
                        else
                            echo 'null';
                        ?>
                    </div>
                </td>
            <?php endforeach; ?>
        </tr>
    <?php endforeach; ?>
</table>
<table>
    <tr>
        <th>
            <div>Item Count</div>
        </th>
        <th>
            <div>Subtotal</div>
        </th>
        <th>
            <div>Shipping</div>
        </th>
        <th>Tax</th>
        <th>Total</th>
    </tr>
    <tr>
        <td>
            <div>
            <?= $orderTotals['ItemCount'] ?>
            </div>
        </td>
        <td>
            <div>
            <?= $orderTotals['Subtotal'] ?>
            </div>
        </td>
        <td>
            <div>
            <?= $orderTotals['Shipping'] ?>
            </div>
        </td>
        <td>
            <div>
            <?= $orderTotals['Tax'] ?>
            </div>
        </td>
        <td>
            <div>
            <?= $orderTotals['Total'] ?>
            </div>
        </td>
    </tr>
</table>
<?php include_once '../view/footer.php' ?>