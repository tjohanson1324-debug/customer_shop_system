<?
include_once __DIR__ . '/../model/CartModel.php';
include_once __DIR__ . '/../model/EmployeeModel.php';
include_once __DIR__ . '/../services/EmployeeService.php';

$action = filter_input(INPUT_GET, 'action');
if ($action == null)
    $action = filter_input(INPUT_POST, 'action');
if ($action == null)
    $action = 'list_carts';
$cartModel = new CartModel($db);
$employeeModel = new EmployeeModel($db);
$employeeService = new EmployeeService($employeeModel);
if (!$employeeService->isLoggedIn())
    header("Location: ../auth_manager/");
switch ($action) {
    case 'list_carts':
        $carts = $cartModel->getCarts();
        include_once('cart_list.php');
        break;
    case 'show_cart':
        $cartID = $_GET['cartID'];
        $cartItems = $cartModel->getCartItems($cartID);
        $cartTotals = $cartModel->getTotals($cartID);
        include_once('cart.php');
        break;
    default:
        echo 'unknown action';
        break;
}
