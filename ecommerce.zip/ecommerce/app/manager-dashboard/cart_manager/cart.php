<?php include_once '../view/header.php';
$columnNames = ['Product Name', 'Quantity', 'Price', 'Subtotal']
?>
<table>
    <tr>
        <?php foreach ($columnNames as $columnName): ?>
            <th>
                <div>
                    <?= $columnName ?>
                </div>
            </th>
        <?php endforeach; ?>
    </tr>
    <?php foreach ($cartItems as $cartItem): ?>
        <tr>
            <?php foreach ($columnNames as $columnName): ?>
                <td>
                    <div>
                        <?php
                        $data = $cartItem[str_replace(' ', '', $columnName)];
                        if ($data != null)
                            echo $data;
                        else
                            echo 'null';
                        ?>
                    </div>
                </td>
            <?php endforeach ?>
        </tr>
    <?php endforeach; ?>
</table>
<table>
    <tr>
        <th>
            <div>
                ItemCount
            </div>
        </th>
        <th>
            <div>
                Total Cost
            </div>
        </th>
    </tr>
    <tr>
        <td>
            <div>
                <?= $cartTotals['ItemCount'] ?>
            </div>
        </td>
        <td>
            <div>
                $<?= round($cartTotals['CartCostTotal'], 2) ?>
            </div>
        </td>
    </tr>
</table>
<?php include_once '../view/footer.php' ?>