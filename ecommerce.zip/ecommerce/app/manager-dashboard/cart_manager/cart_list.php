<?php include_once '../view/header.php';
$columnNames = ['Email', 'Item Count', 'Cart Cost Total'];
?>
<table>
    <tr>
        <?php foreach ($columnNames as $columnName): ?>
            <th>
                <div> <?= $columnName ?></div>
            </th>
        <?php endforeach; ?>
    </tr>
    <?php foreach ($carts as $cart): ?>
        <tr>
            <?php foreach ($columnNames as $columnName): ?>
                <td>
                    <div>
                        <?php
                        $data = $cart[str_replace(' ', '', $columnName)];
                        if ($data != null)
                            echo $data;
                        else
                            echo 'null';
                        ?>
                    </div>
                </td>
            <?php endforeach; ?>
            <td>
                <a href="index.php?action=show_cart&cartID=<?= $cart['ID'] ?>">View</a>
            </td>
        </tr>
    <?php endforeach; ?>
</table>
<?php include_once '../view/footer.php' ?>