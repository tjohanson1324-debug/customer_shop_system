<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Solar System MVC</title>
    <link rel="stylesheet" href="../styles/main.css">
</head>

<body>
    <header>
        <h1>Customer Order And Cart System</h1>
        <nav>
            <ul>
                <li>
                    <a href="../cart_manager/">View Carts</a>
                </li>
                <li>
                    <a href="../auth_manager/index.php?action=show_login">Login</a>
                </li>
                <li>
                    <a href="../auth_manager/index.php?action=show_register">Register</a>
                </li>
                <li>
                    <a href="../product_manager/">Manage Products</a>
                </li>
                <li>
                    <a href="../order_manager/">View Orders</a>
                </li>
                <li>
                    <a href="../customer_manager/">Manage Customers</a>
                </li>
            </ul>
        </nav>
    </header>
    <main>