<?
include_once __DIR__ . '/../model/CustomerModel.php';
include_once __DIR__ . '/../model/EmployeeModel.php';
include_once __DIR__ . '/../services/EmployeeService.php';

$action = filter_input(INPUT_GET, 'action');
if ($action == null)
    $action = filter_input(INPUT_POST, 'action');
if ($action == null)
    $action = 'list_customers';
$employeeModel = new EmployeeModel($db);
$employeeService = new EmployeeService($employeeModel);
$customerModel = new CustomerModel($db);
if (!$employeeService->isLoggedIn())
    header("Location: ../auth_manager/");
switch ($action) {
    case 'list_customers':
        $customers = $customerModel->getCustomers();
        include_once('customer_list.php');
        break;
    case 'view_customer':
        $customerID = $_GET['customer_id'];
        $customerInfo = $customerModel->getCustomerByID($customerID);
        include_once('customer_details.php');
        break;
}
