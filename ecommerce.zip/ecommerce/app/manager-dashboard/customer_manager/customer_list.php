<?php include_once '../view/header.php';
$columnNames = [
    'Email',
    'Password',
    'First Name',
    'Last Name',
    'Shipping Street',
    'Shipping City',
    'Shipping State',
    'Shipping Zip',
    'Billing Street',
    'Billing City',
    'Billing State',
    'Billing Zip'
]
?>
<table>
    <tr>
        <?php foreach ($columnNames as $columnName): ?>
            <th>
                <div>
                    <?= $columnName ?>
                </div>
            </th>
        <?php endforeach; ?>
    </tr>
    <?php foreach ($customers as $customer): ?>
        <tr>
            <?php foreach ($columnNames as $columnName): ?>
                <td>
                    <div>
                        <?php
                        $data = $customer[str_replace(' ', '', $columnName)];
                        if ($data !== null)
                            echo $data;
                        else
                            echo 'null';
                        ?>
                    </div>
                </td>
            <?php endforeach; ?>
            <td>
                <div>
                    <a href="index.php?action=view_customer&customer_id=<?= $customer['ID'] ?>">View</a>
                </div>
            </td>
        </tr>
    <?php endforeach; ?>
</table>
<?php include_once '../view/footer.php' ?>