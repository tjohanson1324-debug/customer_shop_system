<?php

class OrderModel
{
    private $db;
    public function __construct(PDO $databaseConnection)
    {
        $this->db = $databaseConnection;
    }

    public function getOrderItems(int $orderID)
    {
        $sql = $this->db->prepare('SELECT * FROM vOrderDetails WHERE OrderID  = :orderID');
        $sql ->execute([':orderID' => $orderID]);
        $orderItems = $sql->fetchAll();
        return $orderItems;
    }
    
    public function getOrderByID(int $orderID)
    {
        $sql = $this->db->prepare('SELECT * FROM `Order` o
        JOIN Cart c ON o.CartID = c.ID
        WHERE o.ID = :id');
        $sql ->execute([':id'=>$orderID]);
        $order = $sql->fetch();
        return $order;
    }

    public function getOrders() {
        $sql = $this->db->prepare('SELECT o.*, c.Email FROM `Order` o
        JOIN Cart ct ON o.CartID = ct.ID
        JOIN Customer c ON ct.CustomerID = c.ID
        ');
        $sql-> execute();
        $Orders = $sql ->fetchAll();
        return $Orders;
    }
}
