<?php

include_once('database.php');

class CustomerModel
{
    private PDO $db;
    public function __construct(PDO $databaseConnection)
    {
        $this->db = $databaseConnection;
    }
    public function getUserCartID(int $CustomerID)
    {
        $sql = $this->db->prepare('SELECT ID FROM Cart WHERE CustomerID = :customerID');
        $sql ->execute([':customerID'=>$CustomerID]);
        $cartID = $sql->fetch();
        return $cartID['ID'];
    }
    public function getCustomers()
    {
        $sql = $this->db->prepare('SELECT * FROM vCustomerDetails');
        $sql ->execute();
        $Customers = $sql = $sql->fetchAll();
        return $Customers;
    }
    public function getCustomerByID($CustomerID)
    {
        $sql = $this->db->prepare('SELECT * FROM vCustomerDetails WHERE ID = :id');
        $sql ->execute([':id'=>$CustomerID]);
        $Customer = $sql->fetchAll();
        return $Customer;
    }
}
