<?php

include_once('database.php');

class EmployeeModel
{
    private PDO $db;
    public function __construct(PDO $databaseConnection)
    {
        $this->db = $databaseConnection;
    }
    public function findByEmail(string $email)
    {
        $sql = $this->db->prepare('SELECT * FROM Employee WHERE Email = :email');
        $sql->execute([':email' => $email]);
        $emplyoee = $sql->fetch();
        return $emplyoee;
    }
    public function registerEmployee($email, $password, $firstName, $lastName)
    {
        $sql = $this->db->prepare('INSERT INTO Employee(Email,Password,FirstName,LastName)
            VALUES(:email,:password,:firstName,:lastName)
        ');
        $sql->execute([
            ':email' => $email,
            ':password' => $password,
            ':firstName' => $firstName,
            ':lastName' => $lastName
        ]);
    }
}
