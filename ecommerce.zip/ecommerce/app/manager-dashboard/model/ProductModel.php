<?php
class ProductModel
{
    private $db;
    public function __construct(PDO $databaseConnection)
    {
        $this->db = $databaseConnection;
    }
    public function getProductById(int $ProductID)
    {
        $sql = $this->db->prepare('SELECT * FROM Product WHERE ID = :ID');
        $sql->execute([':ID' => $ProductID]);
        $product = $sql->fetch();
        return $product;
    }
    public function getProducts()
    {
        $sql = $this->db->prepare('SELECT * FROM Product');
        $sql->execute();
        $products = $sql ->fetchAll();
        return $products;
    }
    public function editProduct(int $productID, string $productName, float $price, float $discountPercent)
    {
        $sql = $this->db->prepare('UPDATE Product
        SET 
         ProductName = :prodcutName,
         DiscountPercent = :discountPercent,
         Price = :price
         WHERE ID = :productID
         ');
         $sql ->execute([':productName'=>$productName, ':discountPercent' => $discountPercent, ':price'=>$price, 
         ':productID' => $productID]);
    }
    public function addProduct(string $productName, float $price, float $discountPercent)
    {
        $sql = $this->db->prepare('INSERT INTO Product(ProductName, DiscountPercent,Price)
        VALUES(:productName, :discountPercent, :price)');
        $sql->execute([':productName'=>$productName,':discountPercent'=>$discountPercent, ':price'=>$price]);
    }
}
