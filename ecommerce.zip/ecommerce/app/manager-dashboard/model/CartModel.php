<?php
class CartModel
{
    private $db;
    public function __construct(PDO $datbaseConnection)
    {
        $this->db = $datbaseConnection;
    }
    public function getTotals(int $cartID)
    {
        global $db;
        $sql = 'SELECT * FROM vCartTotal WHERE ID = :id';
        $stmt1 = $db->prepare($sql);
        $stmt1->execute([':id' => $cartID]);
        $CartTotals = $stmt1->fetch();
        return $CartTotals;
    }
    public function getCartItems(int $cartID)
    {
        $sql = $this->db->prepare('SELECT * FROM vCartDetails WHERE CartID = :ID');
        $sql -> execute([':ID' => $cartID]);
        $CartData = $sql -> fetchAll();
        return $CartData;
    }
    public function getCarts()
    {
        $sql= $this->db->prepare('SELECT ctt.*, c.Email FROM vCartTotal ctt
        JOIN Cart ct ON ctt.ID = ct.ID
        JOIN Customer c ON ct.CustomerID = c.ID
        ');
        $sql->execute();
        $carts = $sql->fetchAll();
        return $carts;
    }
}
