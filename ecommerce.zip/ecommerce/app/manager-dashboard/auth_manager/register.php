<?php include_once '../view/header.php' ?>
<form method="post" action="index.php?action=register_employee">
    <label for="email">Email</label>
    <input name="email" type="email" id="email">
    <label for="password">Password</label>
    <input name="password" type="password" id="password">
    <label for="firstName">First Name</label>
    <input name="firstName" id="firstName">
    <label for="lastName">LastName</label>
    <input name="lastName" id="lastName">
    <button type="submit">Submit</button>
</form>
<?php include_once '../view/footer.php' ?>