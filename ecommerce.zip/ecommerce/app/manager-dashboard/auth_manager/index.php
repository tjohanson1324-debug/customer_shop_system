<?
include_once __DIR__ . '/../model/EmployeeModel.php';
include_once __DIR__ .'./../model/StateModel.php';
include_once __DIR__ . '/../services/EmployeeService.php';

$action = filter_input(INPUT_GET, 'action');
if ($action == null)
    $action = filter_input(INPUT_POST, 'action');
if ($action == null)
    $action = 'show_login';
$employeeModel = new EmployeeModel($db);
$stateModel = new StateModel($db);
$employeeService = new EmployeeService($employeeModel);
switch ($action) {
    case 'show_login':
        include_once('login.php');
        break;
    case 'verify_login':
        $email =  $_POST['email'];
        $password =  $_POST['password'];
        if ($employeeService->logIn($email, $password)) {
            header('Location: ../order_manager/');
            exit;
        } else {
            $error = 'incorect email or password';
            include_once('login.php');
        }
        break;
    case 'show_register':
        $states = $stateModel->getStates();
        include_once('register.php');
        break;
    case 'register_employee':
        $email = $_POST['email'];
        $password =  $_POST['password'];
        $firstName = $_POST['firstName'];
        $lastName = $_POST['lastName'];
        if ($employeeService->register(
            $email,
            $password,
            $firstName,
            $lastName
        )) {
            header('Location: index.php?action=login');
            exit();
        }
    default:
        echo 'unknown action';
        break;
}
