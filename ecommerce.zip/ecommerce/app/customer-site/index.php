<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

if(session_status() === PHP_SESSION_NONE)
    session_start();
date_default_timezone_set('UTC');

require_once __DIR__. '/../src/Model/UserModel.php';
require_once __DIR__. '/../src/Model/ProductModel.php';
require_once __DIR__. '/../src/model/CartModel.php';
require_once __DIR__. '/../src/model/OrderModel.php';

require_once __DIR__. '/../src/services/UserService.php';
require_once __DIR__. '/../src/services/cartService.php';
require_once __DIR__. '/../src/services/OrderService.php';

require_once __DIR__. '/../src/model/database.php';

$userModel = new UserModel($db);
$cartModel = new CartModel($db);
$productModel = new ProductModel($db);
$orderModel = new OrderModel($db);

?>