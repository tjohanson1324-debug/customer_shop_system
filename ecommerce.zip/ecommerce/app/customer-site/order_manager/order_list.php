<?php include_once '../view/header.php';
$columnNames = ['Item Count','Subtotal','Shipping','Tax','Total','Order Date']
?>
<table>
    <tr>
        <?php foreach($columnNames as $columnName): ?>
            <th>
                <?= $columnName ?>
            </th>
        <?php endforeach; ?>
    </tr>
    <?php foreach($orders as $order): ?>
        <tr>
            <?php foreach($columnNames as $columnName): ?>
                <td>
                    <?php
                     $data = $order[str_replace(' ', '', $columnName)];
                        if ($data !== null)
                            echo $data;
                        else
                            echo 'null';
                     ?>
                </td>
            <?php endforeach; ?>
            <td>
                <a href="index.php?action=view_order&order_id=<?= $order['ID'] ?>">View</a>
            </td>
        </tr>
    <?php endforeach; ?>
</table>
<?php include_once '../view/footer.php' ?>
