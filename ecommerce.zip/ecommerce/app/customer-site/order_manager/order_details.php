<?php include_once '../view/header.php';
$columnNames = ['Product Name', 'Price', 'Quantity'];
?>
<table>
    <tr>
        <?php foreach ($columnNames as $columnName): ?>
            <th><?= $columnName ?></th>
        <?php endforeach ?>
    </tr>
    <?php foreach ($orderItems as $orderItem): ?>
        <tr>
            <?php foreach ($columnNames as $columnName): ?>
                <td>
                    <?php
                    $data = $orderItem[str_replace(' ', '', $columnName)];
                    if ($data !== null)
                        echo $data;
                    else
                        echo 'null';
                    ?>
                </td>
            <?php endforeach; ?>
        </tr>
    <?php endforeach; ?>
</table>
<table>
    <tr>
        <th>Item Count</th>
        <th>Subtotal</th>
        <th>Shipping</th>
        <th>Tax</th>
        <th>Total</th>
    </tr>
    <tr>
        <td>
            <?= $orderTotals['ItemCount'] ?>
        </td>
        <td>
            <?= $orderTotals['Subtotal'] ?>
        </td>
        <td>
            <?= $orderTotals['Shipping'] ?>
        </td>
        <td>
            <?= $orderTotals['Tax'] ?>
        </td>
        <td>
            <?= $orderTotals['Total'] ?>
        </td>
    </tr>
</table>
<?php include_once '../view/footer.php' ?>