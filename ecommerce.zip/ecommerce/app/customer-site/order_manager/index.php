<?php
include_once __DIR__ . '/../model/CustomerModel.php';
include __DIR__ . '/../model/OrderModel.php';
include_once __DIR__ . '/../services/CustomerService.php';

$action = filter_input(INPUT_GET, 'action');
if ($action == null)
    $action = filter_input(INPUT_POST, 'action');
if ($action == null)
    $action = 'list_orders';
$customerModel = new CustomerModel($db);
$customerService = new CustomerService($customerModel);
$orderModel = new OrderModel($db);
if (!$customerService->isLoggedIn())
    header("Location: ../auth_manager/");
else
    $user = $customerService->getCurrentCustomer();
switch ($action) {
    case 'list_orders':
        $orders = $orderModel->getOrders($user['id']);
        include_once('order_list.php');
        break;
    case 'make_order':
        $cartID = $customerModel->getUserCartID($user['id']);
        $orderID = $orderModel->makeOrder($cartID,$user['id']);
        header("Location: index.php?action=view_order&order_id=".$orderID);
        exit();
    case 'view_order':
        $orderID = $_GET['order_id'];
        $orderItems = $orderModel->getOrderItems($user['id'],$orderID);
        $orderTotals = $orderModel->getOrderByID($orderID,$user['id']);
        include_once('order_details.php');
        break;
}
