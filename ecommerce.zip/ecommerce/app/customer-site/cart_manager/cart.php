<?php include_once '../view/header.php';
$columnNames = ['Product Name', 'Quantity', 'Price', 'Subtotal']
?>
<p>Welcome <?= $email ?></p>
<table>
    <tr>
        <?php foreach ($columnNames as $columnName): ?>
            <th>
                <?= $columnName ?>
            </th>
        <?php endforeach; ?>
    </tr>
    <?php foreach ($cartItems as $cartItem): ?>
        <tr>
            <?php foreach ($columnNames as $columnName): ?>
                <td>
                    <?php if ($columnName != 'Quantity'): ?>
                        <?php
                        $data = $cartItem[str_replace(' ', '', $columnName)];
                        if ($data != null)
                            echo $data;
                        else
                            echo 'null';
                        ?>
                    <?php else: ?>
                        <form action="index.php" method="post">
                            <input name="action" type="hidden" value="change_quantity">
                            <input name="productID" type="hidden" value="<?= $cartItem['ProductID'] ?>">
                            <input type="number" name="quantity" min=1 max=99
                                value="<?= $cartItem[str_replace(' ', '', $columnName)]; ?>">
                            <button type="submit">Set</button>
                        </form>
                    <?php endif; ?>
                </td>
            <?php endforeach ?>
            <td>
                <form action="index.php" method="post">
                    <input name="action" type="hidden" value="delete_item">
                    <input name="productID" type="hidden" value="<?= $cartItem['ProductID'] ?>">
                    <button type="submit">Delete</button>
                </form>
            </td>
        </tr>
    <?php endforeach; ?>
</table>
<table>
    <tr>
        <th>
            ItemCount
        </th>
        <th>
            Total Cost
        </th>
    </tr>
    <tr>
        <td>
            <?= $cartTotals['ItemCount'] ?>
        </td>
        <td>
            $<?= round($cartTotals['CartCostTotal'], 2) ?>
        </td>
    </tr>
</table>
<form action="index.php" method="post">
    <input name="action" value="make_order" type="hidden">
    <button type="submit">Order Items</button>
</form>
<?php include_once '../view/footer.php' ?>