<?php include_once '../view/header.php';
$inputNames = ['Product Name', 'Price']
?>
 <?php foreach($inputNames as $inputName): $keyName = str_replace(' ','',$inputName); ?>
        <p><?= $keyName ?>: <?= $product[$keyName] ?> </p>
    <?php endforeach ?>
<form action="index.php" method="post">
    <input name="action" value="add_item" type="hidden">
    <input name="productID" value="<?=$product['ID']?>" type="hidden"> 
    <label for="quantity">Quantity</label>
    <input name="quantity" id="quantity" value="1" required min = 1 max = 99 type="number">
    <button type="submit">Add to Cart</button>
</form>
<?php include '../view/footer.php' ?>