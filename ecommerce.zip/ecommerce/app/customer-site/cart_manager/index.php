<?
include_once __DIR__ . '/../model/CartModel.php';
include_once __DIR__ . '/../model/CustomerModel.php';
include_once __DIR__ . '/../model/ProductModel.php';
include_once __DIR__ . '/../services/CustomerService.php';

$action = filter_input(INPUT_GET, 'action');
if ($action == null)
    $action = filter_input(INPUT_POST, 'action');
if ($action == null)
    $action = 'show_cart';
$cartModel = new CartModel($db);
$customerModel = new CustomerModel($db);
$productModel = new ProductModel($db);
$customerService = new CustomerService($customerModel);
if (!$customerService->isLoggedIn())
    header("Location: ../auth_manager/");
else {
    $user = $customerService->getCurrentCustomer();
    $cartID = $customerModel->getUserCartID($user['id']);
}
switch ($action) {
    case 'show_cart':
        $cartItems = $cartModel->getCartItems($cartID);
        $email = $user['email'];
        $cartTotals = $cartModel->getTotals($cartID);
        include_once('cart.php');
        break;
    case 'show_add_item':
        $productID = $_GET['productID'];
        $product = $productModel->getProductById($productID);
        include_once('add_item.php');
        break;
    case 'add_item':
        $productID = $_POST['productID'];
        $Quantity = $_POST['quantity'];
        $cartModel->updateOrAddItem($cartID, $productID, $Quantity);
        header("Location: index.php?action=show_cart");
        exit();
    case 'delete_item':
        $productID = $_POST['productID'];
        $cartModel->deleteItem($cartID, $productID);
        header("Location: index.php?action=show_cart");
        exit();
    case 'change_quantity':
        $Quantity = $_POST['quantity'];
        $productID = $_POST['productID'];
        $cartModel->updateOrAddItem($cartID, $productID, $Quantity);
        header("Location: index.php?action=show_cart");
        exit();
    case 'make_order':
        header('Location: ../order_manager/index.php?action=make_order');
        break;
}
