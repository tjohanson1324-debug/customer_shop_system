<?php include_once '../view/header.php';
$columnNames = ['Product Name', 'Discount Percent', 'Price']
?>
<table>
    <tr>
        <?php foreach ($columnNames as $columnName): ?>
            <th>
                <?= $columnName ?>
            </th>
        <?php endforeach; ?>
    </tr>
    <?php foreach ($products as $product): ?>
        <tr>
            <?php foreach ($columnNames as $columnName): ?>
                <td>
                    <?php
                    $data = $product[str_replace(' ', '', $columnName)];
                    if ($data != null)
                        echo $data;
                    else
                        echo 'null';
                    ?>
                </td>
            <?php endforeach ?>
            <td>
                <form method="post" action="index.php?action=add_product_to_cart">
                    <input value="<?= $product['ID'] ?>" name="ProductID" type="hidden">
                    <button type="submit">Add to Cart</button>
                </form>
            </td>
        </tr>
    <?php endforeach ?>
</table>
<?php include '../view/footer.php' ?>