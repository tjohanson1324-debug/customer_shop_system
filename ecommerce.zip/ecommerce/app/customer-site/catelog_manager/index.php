<?php
include_once __DIR__. '/../model/database.php';
include_once __DIR__ .'/../model/ProductModel.php';

$action = filter_input(INPUT_GET, 'action');
if ($action == null)
    $action = filter_input(INPUT_POST, 'action');
if ($action == null)
    $action = 'list_products';
$productModel = new ProductModel($db);
switch ($action) {
    case 'list_products':
        $products = $productModel->getProducts();
        include_once 'product_list.php';
    break;
    case 'add_product_to_cart':
        $ProdudctID = $_POST['ProductID'];
        header("Location: ../cart_manager/index.php?action=show_add_item&productID=".$ProdudctID);
}
