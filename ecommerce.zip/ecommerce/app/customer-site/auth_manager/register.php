<?php include_once '../view/header.php' ?>
<form method="post" action="index.php?action=register_customer">
    <label for="email">Email</label>
    <input name="email" type="email" id="email">
    <label for="password">Password</label>
    <input name="password" type="password" id="password">
    <label for="firstName">First Name</label>
    <input name="firstName" id="firstName">
    <label for="lastName">LastName</label>
    <input name="lastName" id="lastName">
    <label for="shippingStreet">Shipping Street</label>
    <input name="shippingStreet" id ="shippingStreet">
    <label for="shippingCity">Shipping City</label>
    <input name="shippingCity" id = "shippingCity">
    <label for="shippingStateID">Shipping State</label>
    <select name="shippingStateID" id ="shippingStateID">
        <?php foreach($states as $state): ?>
            <option value="<?= $state['ID'] ?>"><?= $state['StateName'] ?></option>
        <?php endforeach; ?>
    </select>
    <label for="shippingZip">Shipping Zip</label>
    <input name="shippingZip" id = "shippingZip">
    <label for="billingStreet">Billing Street</label>
    <input name="billingStreet" id = "billingStreet">
    <label for="billingCity">Billing City</label>
    <input name="billingCity" id = "billingCity">
    <label for="billingStateID">Billing State</label>
    <select name="billingStateID" id = "billingStateID">
        <?php foreach($states as $state): ?>
            <option value="<?= $state['ID'] ?>"><?= $state['StateName'] ?></option>
        <?php endforeach; ?>
    </select>
    <label for="billingZip">Billing Zip</label>
    <input name="billingZip" id = "billingZip">
    <button type="submit">Submit</button>
</form>
<?php include_once '../view/footer.php' ?>