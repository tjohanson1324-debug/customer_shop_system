<?
include_once __DIR__ . '/../model/CustomerModel.php';
include_once __DIR__ .'./../model/StateModel.php';
include_once __DIR__ . '/../services/CustomerService.php';

$action = filter_input(INPUT_GET, 'action');
if ($action == null)
    $action = filter_input(INPUT_POST, 'action');
if ($action == null)
    $action = 'show_login';
$customerModel = new CustomerModel($db);
$stateModel = new StateModel($db);
$customerService = new CustomerService($customerModel);
switch ($action) {
    case 'show_login':
        include_once('login.php');
        break;
    case 'verify_login':
        $email =  $_POST['email'];
        $password =  $_POST['password'];
        if ($customerService->logIn($email, $password)) {
            header('Location: ../cart_manager/');
            exit;
        } else {
            $error = 'incorect email or password';
            include_once('login.php');
        }
        break;
    case 'show_register':
        $states = $stateModel->getStates();
        include_once('register.php');
        break;
    case 'register_customer':
        $email = $_POST['email'];
        $password =  $_POST['password'];
        $firstName = $_POST['firstName'];
        $lastName = $_POST['lastName'];
        $shippingStreet = $_POST['shippingStreet'];
        $shippingCity = $_POST['shippingCity'];
        $shippingStateID = $_POST['shippingStateID'];
        $shippingZip = $_POST['shippingZip'];
        $billingStreet = $_POST['billingStreet'];
        $billingCity = $_POST['billingCity'];
        $billingStateID = $_POST['billingStateID'];
        $billingZip = $_POST['billingZip'];
        if ($customerService->register(
            $email,
            $password,
            $firstName,
            $lastName,
            $shippingStreet,
            $shippingCity,
            $shippingStateID,
            $shippingZip,
            $billingStreet,
            $billingCity,
            $billingStateID,
            $billingZip
        )) {
            header('Location: index.php?action=login');
            exit();
        }
    default:
        echo 'unknown action';
        break;
}
