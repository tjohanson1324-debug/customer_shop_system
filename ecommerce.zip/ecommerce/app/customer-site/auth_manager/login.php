<?php include_once '../view/header.php'?>
<?php if(isset($error)): ?>
    <p><?= $error ?></p>
<?php endif ?>
<form method="post" action="index.php?action=verify_login">
    <label>Email</label>
    <input name="email" id = "email">
    <label>Password</label>
    <input name="password" id = "password">
    <button type="submit">Login</button>
</form>
<?php include_once '../view/footer.php'?>