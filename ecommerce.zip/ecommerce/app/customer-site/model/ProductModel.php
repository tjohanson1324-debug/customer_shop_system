<?php
class ProductModel
{
    private $db;
    public function __construct(PDO $databaseConnection)
    {
        $this->db = $databaseConnection;
    }
   public function getProductById($ProductID)
   {
        
   }
}
