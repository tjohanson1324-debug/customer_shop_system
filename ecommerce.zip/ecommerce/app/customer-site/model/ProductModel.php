<?php
class ProductModel
{
    private $db;
    public function __construct(PDO $databaseConnection)
    {
        $this->db = $databaseConnection;
    }
    public function getProductById(int $ProductID)
    {
        $sql = $this->db->prepare('SELECT * FROM Product WHERE ID = :ID');
        $sql->execute([':ID' => $ProductID]);
        $product = $sql->fetch();
        return $product;
    }
    public function getProducts()
    {
        $sql = $this->db->prepare('SELECT * FROM Product');
        $sql->execute();
        $products = $sql ->fetchAll();
        return $products;
    }
}
