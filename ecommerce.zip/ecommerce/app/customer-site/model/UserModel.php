<?php

include_once('database.php');

class UserModel
{
    private PDO $db;
    public function __construct(PDO $databaseConnection)
    {
        $this->db = $databaseConnection;
    }
    public function createUser(int $email, string $password, string $firstName, string $lastName)
    {
            $passwordHash = password_hash($password, PASSWORD_BCRYPT);
            $sql = $this->db->prepare('INSERT INTO User (FirstName, LastName, Email, Password) 
    VALUES(:firstName, :lastName, :email, :password)');
            $sql->execute([
                ':firstName' => $firstName,
                ':lastName' => $lastName,
                ':email' => $email,
                ':password' => $passwordHash
            ]);
          return $this->db->lastInsertId();
    }
   public function findByEmail(string $email)
    {
        $sql = $this->db->prepare('SELECT * FROM User WHERE Email = :email');
        $sql->execute([':email' => $email]);
        $user = $sql->fetch();
        return $user;
    }
}
