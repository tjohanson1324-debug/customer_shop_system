<?php 
class StateModel
{
    private $db;
    public function __construct(PDO $databaseConnection)
    {
        $this->db = $databaseConnection;
    }
    public function getStates()
    {
        $sql = $this->db->prepare('SELECT * FROM StateSalesTax');
        $sql ->execute();
        $states = $sql ->fetchAll();
        $sql->closeCursor();
        return $states;
    }
}
?>