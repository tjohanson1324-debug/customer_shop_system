<?php

include_once('database.php');

class CustomerModel
{
    private PDO $db;
    public function __construct(PDO $databaseConnection)
    {
        $this->db = $databaseConnection;
    }
    public function createCustomer(string $email, string $password, string $firstName, string $lastName, 
    string $shippingStreet, string $shippingCity, int $shippingStateID, string $shippingZip,
    string $billingStreet, string $billingCity, int $billingStateID, string $billingZip)
    {
        $sql = $this->db->prepare('CALL spRegisterCustomer(:shippingStreet, :shippingCity, :shippingStateID, :shippingZip, 
        :billingStreet, :billingCity,:billingStateID,:billingZip,
        :email, :password, :firstName, :lastName
        )');
        $sql->execute([':shippingStreet'=> $shippingStreet, ':shippingCity'=>$shippingCity, ':shippingStateID' =>$shippingStateID,
        ':shippingZip' => $shippingZip, 
        ':billingStreet' => $billingStreet, ':billingCity' => $billingCity, ':billingStateID' => $billingStateID, 
        'billingZip' => $billingZip, 
        ':email' => $email, ':password' => $password, ':firstName' => $firstName, ':lastName' => $lastName]);
    }
   public function findByEmail(string $email)
    {
        $sql = $this->db->prepare('SELECT * FROM Customer WHERE Email = :email');
        $sql->execute([':email' => $email]);
        $customer = $sql->fetch();
        return $customer;
    }
    public function getUserCartID(int $CustomerID)
    {
        $sql = $this->db->prepare('SELECT ID FROM Cart WHERE CustomerID = :customerID');
        $sql ->execute([':customerID'=>$CustomerID]);
        $cartID = $sql->fetch();
        return $cartID['ID'];
    }
}
