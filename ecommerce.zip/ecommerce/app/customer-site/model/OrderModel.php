<?php

class OrderModel
{
    private $db;
    public function __construct(PDO $databaseConnection)
    {
        $this->db = $databaseConnection;
    }

    public function getOrderData(int $userID, int $orderID)
    {
        $sql = $this->db->prepare('SELECT * FROM vOrderDetails WHERE UserID = :userID AND OrderID  = :orderID');
        $sql ->execute([':userID' => $userID,
        ':orderID' => $orderID
        ]
        );
        $orderItems = $sql->fetchAll();
        return $orderItems;
    }

    public function getOrders(int $userID) {
        $sql = $this->db->prepare('SELECT * FROM vOrderDetails WHERE UserID = :userID');
        $sql-> execute([':userID' => $userID]);
        $orderItems = $sql ->fetchAll();
        return $orderItems;
    }

    function addOrder(int $cartID, float $subtotal, float $shipping, float $tax, float $total, int $itemCount)
    {
        $sql = $this->db->prepare('INSERT INTO CustomerOrder (CartID, Subtotal, Shipping, Tax, Total, ItemCount) 
    VALUES (:cartID, :subtotal, :shipping, :tax, :total, :itemCount)');
        $sql->execute([
            ':cartID' => $cartID,
            'subtotal' => $subtotal,
            ':shipping' => $shipping,
            ':tax' => $tax,
            ':total' => $total,
            ':itemCount' => $itemCount
        ]);
        $id = $this->db->lastInsertId();
        $sql->closeCursor();
        return $id;
    }
    function copyCartItems(int $cartID)
    {
        
    }
}
