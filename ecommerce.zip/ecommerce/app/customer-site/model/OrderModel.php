<?php

class OrderModel
{
    private $db;
    public function __construct(PDO $databaseConnection)
    {
        $this->db = $databaseConnection;
    }

    public function getOrderItems(int $customerID, int $orderID)
    {
        $sql = $this->db->prepare('SELECT * FROM vOrderDetails WHERE CustomerID = :customerID AND OrderID  = :orderID');
        $sql ->execute([':customerID' => $customerID,
        ':orderID' => $orderID]);
        $orderItems = $sql->fetchAll();
        return $orderItems;
    }
    
    public function getOrderByID(int $orderID, int $customerID)
    {
        $sql = $this->db->prepare('SELECT * FROM `Order` o
        JOIN Cart c ON o.CartID = c.ID
        WHERE o.ID = :id AND CustomerID = :customerID');
        $sql ->execute([':customerID' =>$customerID, ':id'=>$orderID]);
        $order = $sql->fetch();
        return $order;
    }

    public function getOrders(int $customerID) {
        $sql = $this->db->prepare('SELECT o.* FROM `Order` o
        JOIN Cart c ON o.CartID = c.ID
        WHERE CustomerID = :customerID');
        $sql-> execute([':customerID' => $customerID]);
        $Orders = $sql ->fetchAll();
        return $Orders;
    }
    public function makeOrder(int $cartID, int $customerID)
    {
        $sql = $this->db->prepare('CALL spMakeOrder(:cartID, :customerID, @orderID)');
        $sql->execute([':cartID' =>$cartID, ':customerID' => $customerID]);
        $sql->closeCursor();

        $outsql = $this->db->prepare('SELECT @orderID');
        $outsql->execute();
        $orderID = $outsql->fetch();
        return $orderID['@orderID'];
    }
}
