<?php
class CartModel
{
    private $db;
    public function __construct(PDO $datbaseConnection)
    {
        $this->db = $datbaseConnection;
    }
    public function addItem(int $cartID, int $productID, int $quantity)
    {
        $sql = $this->db->prepare('INSERT INTO CartItem (CartID, ProductID, Quantity) VALUES (:cartID, :productID, :quantity) 
        ON DUPLICATE KEY UPDATE quantity = quantity + :quantity');
        return $sql->execute([
            ':cartID' => $cartID,
            ':productID' => $productID,
            ':quantity' => $quantity
        ]);
    }
    function updateQuantity(int $cartID, int $itemID, int $quantity)
    {
        $sql = $this->db->prepare('CALL spModifyCartItem(?, ?, ?)');
        return $sql->execute([$cartID,$itemID,$quantity]);
    }
    public function deleteItem(int $cartID, int $itemID)
    {
        $sql = $this->db->prepare('DELETE FROM CartItem WHERE CartID = :cartID AND ID = :id');
        return $sql->execute([
            ':cartID' => $cartID,
            ':id' => $itemID
        ]);
    }
    public function getTotals(int $cartID)
    {
        global $db;
        $sql = 'SELECT * FROM vCartTotal WHERE ID = :id';
        $stmt1 = $db->prepare($sql);
        $stmt1->execute([':id' => $cartID]);
        $CartTotals = $stmt1->fetch();
        return $CartTotals;
    }
    public function getUserCartData(int $UserID)
    {
        $sql = $this->db->prepare('SELECT * FROM vCartDetails WHERE UserID = :ID');
        $sql -> execute([':ID' => $UserID]);
        $CartData = $sql -> fetchAll();
        return $CartData;
    }
    public function createCart(int $UserID)
    {
        $sql = $this->db->prepare('INSERT INTO Cart (UserID) VALUES (:userID)');
        $sql ->execute([':userID' => $UserID]);
    }
}
