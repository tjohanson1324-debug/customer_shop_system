<?php
class CartModel
{
    private $db;
    public function __construct(PDO $datbaseConnection)
    {
        $this->db = $datbaseConnection;
    }
    function updateOrAddItem(int $cartID, int $productID, int $quantity)
    {
        $sql = $this->db->prepare('CALL spModifyCartItem(?, ?, ?)');
        return $sql->execute([$cartID,$productID,$quantity]);
    }
    public function deleteItem(int $cartID, int $itemID)
    {
        $sql = $this->db->prepare('DELETE FROM CartItem WHERE CartID = :cartID AND ProductID = :id');
        return $sql->execute([
            ':cartID' => $cartID,
            ':id' => $itemID
        ]);
    }
    public function getTotals(int $cartID)
    {
        global $db;
        $sql = 'SELECT * FROM vCartTotal WHERE ID = :id';
        $stmt1 = $db->prepare($sql);
        $stmt1->execute([':id' => $cartID]);
        $CartTotals = $stmt1->fetch();
        return $CartTotals;
    }
    public function getCartItems(int $cartID)
    {
        $sql = $this->db->prepare('SELECT * FROM vCartDetails WHERE CartID = :ID');
        $sql -> execute([':ID' => $cartID]);
        $CartData = $sql -> fetchAll();
        return $CartData;
    }
}
