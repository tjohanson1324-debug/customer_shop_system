USE Shop;


DROP TABLE IF EXISTS CartItem;
DROP TABLE IF EXISTS OrderItem; 
DROP TABLE IF EXISTS `Order`;
DROP TABLE IF EXISTS Cart;
DROP TABLE IF EXISTS Customer;
DROP TABLE IF EXISTS Employee;
DROP TABLE IF EXISTS Address;
DROP TABLE IF EXISTS StateSalesTax;
DROP TABLE IF EXISTS Product;
DROP PROCEDURE IF EXISTS spRegisterCustomer;
DROP PROCEDURE IF EXISTS spModifyCartItem;
DROP PROCEDURE IF EXISTS spMakeOrder;

CREATE TABLE StateSalesTax(ID INT AUTO_INCREMENT PRIMARY KEY, StateName VARCHAR(2) NOT NULL, TaxRate DECIMAL(5,4) NOT NULL );


CREATE TABLE Address(ID INT AUTO_INCREMENT PRIMARY KEY, Street VARCHAR(30) NOT NULL, 
City VARCHAR(30) NOT NULL, StateID INT NOT NULL, Zip VARCHAR(7) NOT NULL, FOREIGN KEY(StateID) REFERENCES StateSalesTax(ID) );

CREATE TABLE Customer(ID INT AUTO_INCREMENT PRIMARY KEY, Email VARCHAR(40) NOT NULL UNIQUE, Password VARCHAR(255) NOT  NULL, 
FirstName VARCHAR(40) NOT NULL, LastName VARCHAR(40) NOT NULL, ShippingAddressID INT NOT NULL, BillingAddressID INT NOT NULL, FOREIGN KEY(ShippingAddressID) REFERENCES Address(ID),
FOREIGN KEY(BillingAddressID)  REFERENCES Address(ID));

CREATE TABLE Employee(ID INT AUTO_INCREMENT PRIMARY KEY, Email VARCHAR(40) NOT NULL UNIQUE, Password VARCHAR(255) NOT NULL, 
FirstName VARCHAR(40) NOT NULL, LastName VARCHAR(40) NOT NULL);

CREATE TABLE Cart(ID INT AUTO_INCREMENT PRIMARY KEY, CustomerID INT NOT NULL UNIQUE, 
CONSTRAINT fk_user_cart FOREIGN KEY(CustomerID) REFERENCES Customer(ID) ON DELETE CASCADE);

CREATE TABLE Product(ID INT AUTO_INCREMENT PRIMARY KEY, ProductName VARCHAR(80) NOT NULL,
 DiscountPercent DECIMAL(5,2) NOT NULL, Price DECIMAL(8,2) NOT NULL);

CREATE TABLE `Order`(ID INT AUTO_INCREMENT PRIMARY KEY, CartID INT NOT NULL, ItemCount Int NOT NULL, 
Subtotal DECIMAL(10,2) NOT NULL, Shipping DECIMAL(10,2) NOT NULL, Tax DECIMAL(10,2) NOT NULL, Total DECIMAL(10,2) NOT NULL, 
OrderDate DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP, FOREIGN KEY(CartID) REFERENCES Cart(ID));


CREATE TABLE CartItem(ID INT AUTO_INCREMENT PRIMARY KEY, ProductID INT NOT NULL, CartID INT NOT NULL, 
Quantity INT NOT NULL, Foreign KEY(ProductID) references Product(ID),  Foreign KEY(CartID) references Cart(ID),
CONSTRAINT uk_ProductID UNIQUE (CartID, ProductID)
);


CREATE TABLE OrderItem(ID INT AUTO_INCREMENT PRIMARY KEY, ProductID INT NOT NULL, Price DECIMAL (10,2) NOT NULL, 
OrderID INT NOT NULL, Quantity INT NOT NULL, Foreign KEY(ProductID) references Product(ID),  
Foreign KEY(OrderID) references `Order`(ID));

CREATE OR REPLACE VIEW vCustomerDetails
AS 
    SELECT c.ID, c.Email, c.Password, c.FirstName, c.LastName, 
            sa.Street AS 'ShippingStreet', sa.City AS 'ShippingCity', saState.StateName AS 'ShippingState', sa.Zip AS 'ShippingZip',
            ba.Street AS 'BillingStreet', ba.City AS 'BillingCity', baState.StateName AS 'BillingState', ba.Zip AS 'BillingZip'
    FROM Customer c
    JOIN Address sa ON c.ShippingAddressID = sa.ID
    JOIN Address ba ON c.BillingAddressID = ba.ID
    JOIN StateSalesTax saState ON sa.StateID = saState.ID
    JOIN StateSalesTax baState ON ba.StateID = baState.ID;

CREATE OR REPLACE VIEW vCartTotal
AS
    SELECT c.ID, COALESCE(SUM(ci.Quantity),0) as'ItemCount', 
    COALESCE(Round(SUM(ci.Quantity * (p.Price - (p.Price * (p.DiscountPercent /100)))),2),0) as 'CartCostTotal' FROM Cart c
    LEFT JOIN CartItem ci on c.ID = ci.CartID
    LEFT JOIN Product p on ci.ProductID = p.ID
    Group BY c.ID
    ;
CREATE OR REPLACE VIEW vCartDetails
AS
    SELECT  c.ID as 'CartID', c.CustomerID,
            ci.ProductID, ci.Quantity,
            p.ProductName, p.Price , (ci.Quantity * p.Price) AS Subtotal
     FROM Cart c
    JOIN CartItem ci ON c.ID = ci.CartID
    JOIN Product p ON ci.ProductID = p.ID;

CREATE OR REPLACE VIEW vOrderDetails
AS
    SELECT o.ID as 'OrderID', c.CustomerID, oi.ProductID, p.ProductName, oi.Price, oi.Quantity
    FROM `Order` o
    JOIN OrderItem oi ON o.ID = oi.OrderID
    JOIN Product p ON oi.ProductID = p.ID
    JOIN Cart c ON o.CartID = c.ID;

DELIMITER //

CREATE PROCEDURE spModifyCartItem(
    IN p_cart_id INT,
    IN p_product_id INT,
    IN p_quantity INT
)
BEGIN
    IF  p_quantity <= 0 THEN 
        DELETE FROM CartItem
        WHERE CartID = p_cart_id AND ProductID = p_product_id;
    ELSE
        INSERT INTO CartItem (ProductID, CartID, Quantity)
        VALUES (p_product_id, p_cart_id, p_quantity)
        ON DUPLICATE KEY UPDATE Quantity = Quantity + VALUES(Quantity);
    END IF;
END //

CREATE PROCEDURE spRegisterCustomer(
    IN p_shipping_street VARCHAR(30),
    IN p_shipping_city VARCHAR(30),
    IN p_shipping_state_id INT,
    IN p_shipping_zip VARCHAR(7),
    IN p_billing_street VARCHAR(30),
    IN p_billing_city VARCHAR(30),
    IN p_billing_state_id INT,
    IN p_billing_zip VARCHAR(7),
    IN p_email VARCHAR(40),
    IN p_password VARCHAR(255),
    IN p_first_name VARCHAR(40),
    IN p_last_name VARCHAR(40)
)
BEGIN 
    DECLARE v_CustomerID INT;
    DECLARE v_ShippingAddressID INT;
    DECLARE v_BillingAddressID INT;
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN 
        ROLLBACK;
        SELECT 'An error occured. Transaction rollback.' AS 'Status';
    END;
    START TRANSACTION;

    INSERT INTO `Address`(Street, City, StateID, Zip)
    VALUES (p_shipping_street,p_shipping_city,p_shipping_state_id,p_shipping_zip),
    (p_billing_street,p_billing_city,p_billing_state_id,p_billing_zip);

    SET v_ShippingAddressID = LAST_INSERT_ID();
    SET v_BillingAddressID = LAST_INSERT_ID() +1;

    INSERT INTO Customer(Email,Password,FirstName,LastName,ShippingAddressID,BillingAddressID)
    VALUES(p_email,p_password,p_first_name,p_last_name,v_ShippingAddressID, v_BillingAddressID);

   SET v_CustomerID = LAST_INSERT_ID();

    INSERT INTO Cart(CustomerID)
    VALUES(v_CustomerID);
    COMMIT;
END //

CREATE PROCEDURE spMakeOrder(
   IN p_cart_id INT,
   IN p_customer_id INT,
   OUT r_order_id INT
)
BEGIN 
    DECLARE v_TaxRate DECIMAL(5,4);
    DECLARE v_Tax DECIMAL(10,2);
    DECLARE v_order_id INT;
    DECLARE v_Shipping DECIMAL(10,2);
    DECLARE v_ItemCount INT;
    DECLARE v_CartOwnerID INT;
    DECLARE v_Subtotal DECIMAL(10,2);
    DECLARE v_Total DECIMAL(10,2);
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        ROLLBACK;
        RESIGNAL;
    END;

    SELECT CustomerID INTO v_CartOwnerID FROM Cart 
    WHERE ID = p_cart_id;

    IF v_CartOwnerID <> p_customer_id THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'You do not have permissions to this cart, or this cart does not exist.';
    END IF;

    SELECT str.TaxRate INTO v_TaxRate FROM Customer c
    JOIN Address a ON c.ShippingAddressID = a.ID
    JOIN StateSalesTax str ON a.StateID = str.ID
    WHERE c.ID = p_customer_id;

    SELECT ItemCount, CartCostTotal INTO v_ItemCount, v_Subtotal FROM vCartTotal
    WHERE ID = p_cart_id;

    IF v_ItemCount <= 0 THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'You cannot make an order if your cart is empty!';
    END IF;

    SET v_Tax = v_Subtotal * v_TaxRate;
    IF v_Subtotal >= 50.00 THEN
       SET v_Shipping = 0;
    ELSE
       SET v_Shipping = 11.50;
    END IF;
    
    SET v_Total = v_Tax + v_Subtotal + v_Shipping;
    START TRANSACTION;

    INSERT INTO `Order`(CartID, ItemCount, Subtotal, Shipping, Tax, Total)
    VALUES (p_cart_id,v_ItemCount,v_Subtotal,v_Shipping,v_Tax,v_Total);
    
    SET v_order_id = LAST_INSERT_ID();
    SET r_order_id = v_order_id;

    INSERT INTO OrderItem(ProductID, Price, OrderID, Quantity) 
    SELECT ProductID, Subtotal, v_order_id, Quantity FROM vCartDetails 
    WHERE CartID = p_cart_id;

    DELETE FROM CartItem WHERE CartID = p_cart_id;
    COMMIT;
END //

DELIMITER ;

INSERT INTO Product(ProductName,Price,DiscountPercent) VALUES ('USB-C Cable',12.50,0),('Wireless Mouse',25.00,0),
('Mechanical Keyboard',79.95,0),('Webcam',49.99,0),('Laptop Stand',39.50,0),('USB Hub',31.25,0),('Headset',59.00,0),
('Portable SSD',89.99,0);

INSERT INTO StateSalesTax(StateName, TaxRate) VALUES ('WI',0.05),('MI',0.06),('MN',0.06875),('NY',0.04),('IL',0.0625),('TX',0.0625)
