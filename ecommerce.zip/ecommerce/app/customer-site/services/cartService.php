<?php
include_once __DIR__. '/../model/CartItem.php';
include_once __DIR__. '/../model/CartModel.php';
class cartService
{
    private CartModel $cartModel;
    public function __construct(CartModel $cartModel)
    {
        $this->cartModel = $cartModel;
    }
    public function getCartByUserID(int $userID)
    {
        $rows = $this->cartModel->getUserCartData($userID);
        $cart = [
            'cart_id' => $rows[0]['CartID'],
            'user_id' => $rows[0]['UserID'],
            'items' => [],
            'total' => 0,
            'total_items' => 0
        ];
        foreach ($rows as $row) {
            if ($row['ProductID'] != null) {
                $item = new CartItem(
                    $row['ProductID'],
                    $row['ProductName'],
                    $row['Price'],
                    $row['Quantity'],
                );
                $cart['items'][] = $item;
                $cart['total'] += $item->getSubtotal();
                $cart['total_items'] += $item->getQuantity();
            }
        }
        return $cart;
    }
}
