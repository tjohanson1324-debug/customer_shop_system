<?php


class UserService
{
    private $userModel;
    private $cartModel;
    public function __construct(UserModel $userModel, CartModel $cartModel)
    {
        $this->userModel = $userModel;
        $this->cartModel = $cartModel;
        if(session_status() === PHP_SESSION_NONE)
            session_start();
    }
    public function register($email, $password, $firstName, $lastName)
    {
        if (!$this->userModel->findByEmail($email)) {
            $hassedPassword = password_hash($password, PASSWORD_DEFAULT);
            $UserID = $this->userModel->createUser($email, $hassedPassword, $firstName, $lastName);
            $this->cartModel->createCart($UserID);
        } else
            throw new Exception('An account with is email allready exists.');
    }
    public function logIn($email, $password)
    {
        $user = $this->userModel->findByEmail($email);
        if ($user && password_verify($password, $user['Password'])) {
                session_regenerate_id(true);
                $_SESSION['user_id']=$user['Id'];
                $_SESSION['email'] = $user['Email'];
                $_SESSION['logged_in'] = true;
                $_SESSION['last_activity'] = time();
                return true;
            } else return false;
    }
    public function isLoggedIn()
    {
        return isset($_SESSION['logged_in']) && $_SESSION['logged_in'] === true;
    }
    public function logOut()
    {
        $_SESSION = [];
        if(ini_get("session.use_cookies"))
            {
                $params = session_get_cookie_params();
                setcookie(
                    session_name(),
                    '',
                    time() - 42000,
                    $params['path'],
                    $params['domain'],
                    $params['secure'],
                    $params['httponly']
                );
            }
       session_destroy();
    }
    public function getCurrentUser():?array
    {
        if(!$this->isLoggedIn())
            return null;
        return
        [
            'id' => $_SESSION['user_id'],
            'email' => $_SESSION['email']
        ];
    }
}
