<?php


class CustomerService
{
    private $customerModel;
    public function __construct(CustomerModel $customerModel, )
    {
        $this->customerModel = $customerModel;
        if(session_status() === PHP_SESSION_NONE)
            session_start();
    }
    public function register(string $email, string $password, string $firstName, string $lastName, 
    string $shippingStreet, string $shippingCity, int $shippingStateID, string $shippingZip,
    string $billingStreet, string $billingCity, int $billingStateID, string $billingZip)
    {
        if (!$this->customerModel->findByEmail($email)) {
            $hassedPassword = password_hash($password, PASSWORD_DEFAULT);
           $this->customerModel->createCustomer($email, $hassedPassword, $firstName, $lastName, 
           $shippingStreet,$shippingCity,$shippingStateID, $shippingZip,
           $billingStreet, $billingCity, $billingStateID, $billingZip);
        } else
            throw new Exception('An account with is email allready exists.');
    }
    public function logIn($email, $password)
    {
        $customer = $this->customerModel->findByEmail($email);
        if ($customer && password_verify($password, $customer['Password'])) {
                session_regenerate_id(true);
                $_SESSION['user_id']=$customer['ID'];
                $_SESSION['email'] = $customer['Email'];
                $_SESSION['logged_in'] = true;
                $_SESSION['last_activity'] = time();
                return true;
            } else return false;
    }
    public function isLoggedIn()
    {
        return isset($_SESSION['logged_in']) && $_SESSION['logged_in'] === true;
    }
    public function logOut()
    {
        $_SESSION = [];
        if(ini_get("session.use_cookies"))
            {
                $params = session_get_cookie_params();
                setcookie(
                    session_name(),
                    '',
                    time() - 42000,
                    $params['path'],
                    $params['domain'],
                    $params['secure'],
                    $params['httponly']
                );
            }
       session_destroy();
    }
    public function getCurrentCustomer():?array
    {
        if(!$this->isLoggedIn())
            return null;
        return
        [
            'id' => $_SESSION['user_id'],
            'email' => $_SESSION['email']
        ];
    }
}
