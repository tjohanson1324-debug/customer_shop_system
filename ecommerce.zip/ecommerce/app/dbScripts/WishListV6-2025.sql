-- Drop and recreate the database
DROP DATABASE IF EXISTS WishList;
CREATE DATABASE WishList;
USE WishList;

-- Drop tables if they exist
DROP TABLE IF EXISTS wishListItem;
DROP TABLE IF EXISTS wishList;
DROP TABLE IF EXISTS store;
DROP TABLE IF EXISTS wlUser;
DROP TABLE IF EXISTS wlUserRole;

-- Create wlUserRole table
CREATE TABLE wlUserRole (
  ID           INT AUTO_INCREMENT PRIMARY KEY,
  description  VARCHAR(50) NOT NULL,
  isActive     TINYINT(1) DEFAULT 1
);

-- Create wlUser table
CREATE TABLE wlUser (
  ID            INT AUTO_INCREMENT PRIMARY KEY,
  wlUserRoleID  INT NOT NULL,
  firstName     VARCHAR(20) NOT NULL,
  lastName      VARCHAR(20) NOT NULL,
  password      VARCHAR(20) NOT NULL,
  email         VARCHAR(100) UNIQUE,
  address       VARCHAR(80),
  city          VARCHAR(20),
  st            VARCHAR(2),
  zip           VARCHAR(10),
  phone         VARCHAR(20),
  isActive      TINYINT(1) DEFAULT 1,
  dateCreated   DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  dateUpdated   DATETIME
);

-- Create store table
CREATE TABLE store (
  ID        INT AUTO_INCREMENT PRIMARY KEY,
  name      VARCHAR(30) NOT NULL UNIQUE,
  isActive  TINYINT(1) DEFAULT 1
);

-- Create wishList table
CREATE TABLE wishList (
  ID           INT AUTO_INCREMENT PRIMARY KEY,
  wlUserID     INT NOT NULL,
  description  VARCHAR(80),
  isActive     TINYINT(1) DEFAULT 1,
  dateCreated  DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  dateUpdated  DATETIME
);

-- Create wishListItem table
CREATE TABLE wishListItem (
  ID            INT AUTO_INCREMENT PRIMARY KEY,
  wishListID    INT NOT NULL,
  description   VARCHAR(80),
  quantity      INT NOT NULL,
  storeID       INT,
  notes         VARCHAR(200),
  fulfilledByID INT,
  isActive      TINYINT(1) DEFAULT 1,
  dateCreated   DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  dateUpdated   DATETIME
);

-- Insert wlUserRoles
INSERT INTO wlUserRole (ID, description, isActive) VALUES
(1, 'End User', 1),
(2, 'Administrator', 1);

-- Insert stores
INSERT INTO store (ID, name, isActive) VALUES
(1, 'Amazon', 1),
(2, 'Ebay', 1),
(3, 'Walmart', 1),
(4, 'Kmart', 1),
(5, 'StarBase 11 Books', 0),
(6, 'S-Mart (shop smart...)', 1),
(7, 'Empire Records', 1),
(8, 'VHS Rental', 1),
(9, 'Other', 1);

-- Insert wlUsers
INSERT INTO wlUser (ID, wlUserRoleID, firstName, lastName, password, email, address, city, st, zip, phone, isActive, dateCreated, dateUpdated) VALUES
(1,1, 'James','Kirk','pass', 'jk@st.com', '100 Space Lane','New Richmond', 'WI', '54017','715-555-1111',1, NOW(), null),
(2,1, 'Pavel','Chekov','pass', 'pc@st.com', '200 Galaxy Drive','New Richmond', 'WI', '54017','715-555-2222',1, NOW(), null),
(3,1, 'Montgomery','Scott','pass', 'ms@st.com', '300 LawOfPhysics Road','New Richmond', 'WI', '54017','715-555-3333',1, NOW(), null),
(5,1, 'Nyota','Uhura','pass', 'nh@st.com', '400 StarfleetCalling Road','New Richmond', 'WI', '54017','715-555-4444',1, NOW(), null),
(6,1, 'Hikaru','Sulu','pass', 'hs@st.com', '500 PhotonTorpedo Ave','New Richmond', 'WI', '54017','715-555-5555',1, NOW(), null),
(7,1, 'Leonard','McCoy','pass', 'lm@st.com', '600 CountryDoctor Lane','New Richmond', 'WI', '54017','715-555-6666',1, NOW(), null),
(8,2, 'Admin','User','pass', 'admin@admin.com', '800 UltimatePower Lane','New Richmond', 'WI', '54017','715-555-8888',1, NOW(), null),
(9,1, 'Cmdr','Krug','pass', 'klingon1@klingon.net','900 Kronos Lane','New Richmond', 'WI', '54017','715-555-9999',1, NOW(), null),
(10,1, 'Alidar','Jarak','pass', 'admiral@romulan.net','1000 Romulan Drive','New Richmond', 'WI', '54017','715-555-0001',0, NOW(), null);

-- Insert wishLists
INSERT INTO wishList (ID, wlUserID, description, isActive, dateCreated, dateUpdated) VALUES
(1, 1, 'Kirks WishList', 1, NOW(), null),
(2, 2, 'Scottys List', 1, NOW(), null),
(3, 2, 'Nasty Klingon List', 1, NOW(), null),
(4, 2, 'A Romulan List', 0, NOW(), null);

-- Insert wishListItems
INSERT INTO wishListItem (ID, wishListID, description, quantity, storeID, notes, fulfilledByID, isActive, dateCreated, dateUpdated) VALUES
(1, 1, 'White Tribble', 2, 1, 'Cute and fluffy, just like me', null, 1, NOW(), null),
(2, 1, 'Painting of Spock', 1, 8, 'Only a tasteful picture please', null, 1, NOW(), null),
(3, 7, 'Engineering for Dummies', 1, 1, 'Hard cover if possible', null, 1, NOW(), null);

-- Recreate user and assign privileges
CREATE USER  IF NOT EXISTS 'mgs_user'@'%' IDENTIFIED BY 'pa55word';


GRANT SELECT, INSERT, DELETE, UPDATE ON WishList.* TO 'mgs_user'@'%';

FLUSH PRIVILEGES;
