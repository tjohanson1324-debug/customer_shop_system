-- Drop and recreate the database
DROP DATABASE IF EXISTS sswcustomer;
CREATE DATABASE IF NOT EXISTS sswcustomer;
USE sswcustomer;

-- Drop and recreate customer table
DROP TABLE IF EXISTS customer;
CREATE TABLE customer (
  ID            INT NOT NULL AUTO_INCREMENT,
  emailAddress  VARCHAR(255) NOT NULL,
  password      VARCHAR(60) NOT NULL,
  firstName     VARCHAR(60) NOT NULL,
  lastName      VARCHAR(60) NOT NULL,
  address       VARCHAR(60) NOT NULL,
  city          VARCHAR(40),
  state         VARCHAR(2),
  postalCode    VARCHAR(10),
  isActive      TINYINT(1) DEFAULT 1,
  PRIMARY KEY (ID),
  UNIQUE INDEX emailAddress (emailAddress)
);

-- Insert data into customer table
INSERT INTO customer(ID, firstName, lastName, emailAddress, address, city, state, postalCode, password) VALUES
(1,'Barbara','Fishman','fishy@example.com','21 Mountain Ln','Bearcreek','MT','59007','barba123'),
(2,'Aaron','Jackson','aj17@example.com','417 Rocky Rd','Belfry','MT','59008','aaron123'),
(3,'Jack','Sprawling','sprawlingfarms@example.com','1 Sprawling Farm Rd','Cody','WY','82414','jack123'),
(4,'Randy','Blacksmith','blacksmith@example.com','245 18th Ave','Cody','WY','82414','randy123'),
(5,'Joey','Smith','smittyj@example.com','17 Fourth St','Cody','WY','82414','joey123'),
(6,'Joseph','Otterman','otterman42@example.com','42 Rock Ln','Cody','WY','82414','josep123'),
(7,'Dan','Poleman','poleman@example.net','75 Stream Rd','Cody','WY','82414','dan123'),
(8,'Susan','Miller','susanfarms@example.com','1283 Old Roundabout Rd','Cody','WY','82414','susan123'),
(9,'Richie','Upton','uptonfarms@example.com','155 Cherry Canyon Rd','Cody','WY','82414','richi123'),
(10,'Tom','Rascal','rascalfarms@example.com','1 Rascal Farm Rd','Cody','WY','82414','tom123'),
(11,'Taylor','Johnson','taylor.johnson@example.net','458 Rose Ln','Cody','WY','82414','taylo123'),
(12,'Leslie','Smith','sheepland@example.com','123 Sheepland Rd','Elk Butte','WY','82433','lesli123'),
(13,'Mei','Kostas','meowmeow@example.com','812 Playa Hwy','Elk Butte','WY','82433','mei123'),
(14,'Melanie','Jackson','mj@example.com','42 Blackwater Way','Elk Butte','WY','82433','melan123'),
(15,'Elmer','Jackson','ElmerJ22@example.com','22 Jackson Farm Rd','Garland','WY','82435','elmer123'),
(16,'Billy','Ruffton','br299@example.com','21 Simple Cir','Garland','WY','82435','billy123'),
(17,'Reggie','Baxter','baxterfarms@example.com','880 Powell-Cody Rd','Powell','WY','82440','reggi123'),
(18,'Angie','Hendricks','angie@example.com','27 Locklear Ln','Powell','WY','82440','angie123'),
(19,'Sandra','Pincher','sp231@example.com','53 Verde Ln','Powell','WY','82440','sandr123'),
(20,'Samantha','Smith','ssmith@example.com','14 Rock Ln','Ralston','WY','82440','saman123'),
(21,'Sally','Cruz','scruz@example.com','199 18th Ave','Ralston','WY','82440','sally123'),
(22,'Thomas','Jones','tj@example.com','622 Bobcat Tr','Ralston','WY','82440','thoma123'),
(23,'Billy','Smith','bsmith@example.com','312 Oak Rd','Ralston','WY','82440','billy123'),
(24,'Curt','Billings','curtbillings@example.com','10 Ridgewood Ln','Red Lodge','MT','59068','curt123'),
(25,'Joe','Butt','joe@jb.com','123 Main Street','San Clemente','CA','92112','joe123'),
(26,'James','Gonzalez','thewholething@example.com','16 Rockway Rd','Wapiti','WY','82450','james123');

-- Drop and recreate photo table
DROP TABLE IF EXISTS photo;
CREATE TABLE photo (
  ID          INT NOT NULL AUTO_INCREMENT,
  title       VARCHAR(60) NOT NULL,
  description VARCHAR(255) NOT NULL,
  PRIMARY KEY (ID)
);

-- Insert data into photo table
INSERT INTO photo(ID, title, description) VALUES
(1,'title1','description1'),
(2,'title2','description2'),
(3,'title3','description3'),
(4,'title4','description4'),
(5,'title5','description5');

-- Create and grant privileges to user
CREATE USER  IF NOT EXISTS 'mgs_user'@'%' IDENTIFIED BY 'pa55word';




GRANT SELECT, INSERT, DELETE, UPDATE ON sswcustomer.* TO 'mgs_user'@'%';

FLUSH PRIVILEGES;
