<?php
$cfg['AllowUserDropDatabase'] = true;
